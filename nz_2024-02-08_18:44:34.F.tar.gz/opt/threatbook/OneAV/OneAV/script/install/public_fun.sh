#!/bin/bash

DAEMON="oneavd"
ONETHOR="oneav"
PACKAGE_NAME="OneAV"

LOG_DIR="/var/log/oneav"
LOG_FILE="oneav_script.log"
LOG_PATH="${LOG_DIR}/${LOG_FILE}"

EDR_TITLE='threatbook.OneAV'
EDR_HOME_DIR="/opt/threatbook/OneAV"
EDR_WORK_LINK="${EDR_HOME_DIR}/oneav"
EDR_SCRIPT_DIR="${EDR_WORK_LINK}/script/install"
EDR_THOR_CONF="${EDR_WORK_LINK}/conf/thor.conf"
EDR_PROXY_CONF="${EDR_WORK_LINK}/conf/proxy.conf"
EDR_BIN_ONEEDRD="${EDR_WORK_LINK}/${DAEMON}"
EDR_UMID="/etc/threatbook/oneav/agent/umid"

CRONTAB_FILE="/etc/crontab"
CRON_TASK_LOCK="${LOG_DIR}/cron.lock"
CRON_TASK_FILE_DIR="${EDR_SCRIPT_DIR}"
CRON_TASK_FILE_NAME='oneav_service_monitor.sh'
CRON_TASK_CMD="*/5 * * * * root flock -xn \"${CRON_TASK_LOCK}\" -c '${CRON_TASK_FILE_DIR}/${CRON_TASK_FILE_NAME}'"
CRON_TASK_KEY="${CRON_TASK_FILE_NAME}"

SYS_INITD_DIR="/etc/init.d"
SYS_SYSTEMD_DIR="/etc/systemd/system"

SERVICE_NAME="oneavd"
SERVICE_FILE_INITD="${SERVICE_NAME}.sysv"
SERVICE_FILE_SYSTEMD="${SERVICE_NAME}.service"
SERVICE_FILE_PATH=""

SERVICE_PATH_INITD="${SYS_INITD_DIR}/${SERVICE_NAME}"
SERVICE_PATH_SYSTEMD="${SYS_SYSTEMD_DIR}/${SERVICE_FILE_SYSTEMD}"

ONEEDR_LINK_STOP="/usr/bin/oneav_stop"
ONEEDR_LINK_START="/usr/bin/oneav_start"

ERR_CODE_MIN=100
ERR_CODE=${ERR_CODE_MIN}
ERR_INFO="OK"

log()
{
    echo -e "[ $(date "+%Y/%m/%d %T") ] [$0]  $*" >> ${LOG_PATH}
}

set_err_info()
{
    ERR_INFO="$*"
}

set_err_code()
{
    ERR_CODE=$(( ERR_CODE_MIN + $1 ))

    if [ -n "$2" ] ; then
        set_err_info "$2"
    fi

    return ${ERR_CODE}
}

check_err_code_show() {
    if [ ${ERR_CODE} -gt ${ERR_CODE_MIN} ] ; then
        log "CODE : err_code=${ERR_CODE}"
        log "INFO : err_info=${ERR_INFO}"
        return ${ERR_CODE}
    fi
}

check_err_code_zero() {
    check_err_code_show
    set_err_code 0
}

check_err_code_exit() {
    if [ ${ERR_CODE} -gt ${ERR_CODE_MIN} ] ; then
        log "breakdown, err_code=${ERR_CODE}"
        log "breakdown, err_info=${ERR_INFO}"
        exit $(( ERR_CODE - ERR_CODE_MIN ))
    fi
}

get_pid()
{
    local pid=""; pid=$(ps xo pid,cmd | grep -i 'threatbook\.OneAV' | grep -m 1 "$1" | awk '{print $1}')
    if [ -z "${pid}" ] ; then
        echo 0
    else
        if [[ ${pid} == *[^0-9]* ]] ; then  # 只要含有非数字字符，都返回0，保证PID只能是数字
            echo 0
        else
            echo "${pid}"
        fi
    fi
}


remove_edr_work_link()
{
    if [ "${EDR_WORK_LINK}" = '/' ] ; then return; fi

    if [ -e ${EDR_WORK_LINK} ] ; then
        unlink ${EDR_WORK_LINK}
        if [ -e ${EDR_WORK_LINK} ] ; then
            rm -r ${EDR_WORK_LINK}
        fi
    fi
}
create_edr_work_link()
{
    remove_edr_work_link

    local obj_dir="${EDR_HOME_DIR}/${PACKAGE_NAME}"

    if [ -e ${obj_dir} ] ; then
        ln -s ${obj_dir} ${EDR_WORK_LINK}
        if [ $? -eq 0 ] && [ -d ${EDR_WORK_LINK} ] ; then
            log "\t[YES]: \tcreate work link: ${EDR_WORK_LINK} -> ${obj_dir}"
        else
            log "\t [NO]: \tcreate work link: ${EDR_WORK_LINK} -> ${obj_dir}"
            set_err_code 17
            set_err_info "Failed to create work link"
        fi
    else
        log "\t [NO]: \tcreate work link: ${EDR_WORK_LINK} -> ${obj_dir}"
        set_err_code 27
        set_err_info "Failed to create work link"
    fi
}


FIRST_PROC=0
PROC_INITD=1
PROC_SYSTEMD=2
PROC_UNKNOWN=128
who_is_first_process()
{
    if [ ${FIRST_PROC} -eq 0 ] ; then
        local initd=$(ls -alF /proc/1/exe | grep init | wc -l)
        local systemd=$(ls -alF /proc/1/exe | grep systemd | wc -l)

        if [ ${initd} -eq 1 ] ; then
            FIRST_PROC=${PROC_INITD}
        elif [ ${systemd} -eq 1 ] ; then
            FIRST_PROC=${PROC_SYSTEMD}
        fi
    fi
    return ${FIRST_PROC}
}

service_stop()
{
    who_is_first_process
    case $? in
        "${PROC_INITD}")      service "$1" stop   >> /dev/null 2>&1  ;;
        "${PROC_SYSTEMD}")    systemctl stop "$1" >> /dev/null 2>&1  ;;
    esac
}
service_start()
{
    who_is_first_process
    case $? in
        "${PROC_INITD}")      service "$1" start   >> /dev/null 2>&1 ;;
        "${PROC_SYSTEMD}")    systemctl start "$1" >> /dev/null 2>&1 ;;
    esac
}

reload_crontab_task()
{
    who_is_first_process
    case $? in
        "${PROC_INITD}")
            service crond restart >> /dev/null 2>&1
            if [ $? -ne 0 ] ; then
                service cron restart >> /dev/null 2>&1
            fi
        ;;
        "${PROC_SYSTEMD}")
            systemctl restart cron >> /dev/null 2>&1
            if [ $? -ne 0 ] ; then
                systemctl restart crond >> /dev/null 2>&1
            fi
        ;;
    esac

    if [ $? -eq 0 ] ; then
        log "\t[YES]: \treload crontab service"
    else
        log "\t [NO]: \treload crontab service"
    fi
}

install_crontab_task()
{
    chmod u+x "${CRON_TASK_FILE_DIR}/${CRON_TASK_FILE_NAME}"

    local if_repeat=0; if_repeat=$(cat /etc/crontab | grep "${CRON_TASK_KEY}" | wc -l)

    if [ "${if_repeat}" -ne 0 ] ; then
        log "\t[YES]: \tinstall oneav crontab task"
    else
        echo "${CRON_TASK_CMD}" >> ${CRONTAB_FILE}
        if [ $? -eq 0 ] ; then
            log "\t[YES]: \tinstall oneav crontab task"
        else
            log "\t [NO]: \tinstall oneav crontab task"
        fi
        reload_crontab_task
    fi
}
uninstall_crontab_task()
{
    local if_repeat=$(cat /etc/crontab | grep "${CRON_TASK_KEY}" | wc -l)

    if [ ${if_repeat} -ne 0 ] ; then
        sed -i "/${CRON_TASK_KEY}/d" ${CRONTAB_FILE}
        if [ $? -eq 0 ] ; then
            log "\t[YES]: \tuninstall oneav cron task"
            reload_crontab_task
        else
            log "\t [NO]: \tuninstall oneav cron task"
            upload_err_info "INFO: uninstall oneav crontab task failed"
        fi
    else
        log "INFO: no crontab task need to uninstall"
    fi
}

INITD_METHOD_CODE=0
INITD_METHOD_REDHAT=1
INITD_METHOD_DEBIAN=2
INITD_METHOD_SUSE11=3

judge_os_type()
{
    local info=$(cat $1)

    if [ 0 -lt $(echo "${info}" | grep -iE "CentOS|Redhat" | wc -l) ] ; then
        return ${INITD_METHOD_REDHAT}
    elif [ 0 -lt $(echo "${info}" | grep -iE "Ubuntu|Debian" | wc -l) ] ; then
        return ${INITD_METHOD_DEBIAN}
    elif [ 0 -lt $(echo "${info}" | grep -iE "SUSE" | grep -iE "11" | wc -l) ] ; then
        return ${INITD_METHOD_SUSE11}
    fi
    return 0
}

select_initd_method()
{
    local file_list=(/etc/issue /etc/os-release /etc/SuSE-release)

    for file_path in ${file_list[*]} ; do

        if [ ${INITD_METHOD_CODE} -eq 0 ] && [ -f ${file_path} ] ; then
            judge_os_type ${file_path}
            local os_type=$?
            if [ ${os_type} -eq 0 ] ; then
                continue
            else
                INITD_METHOD_CODE=${os_type}
                break
            fi
        fi
    done
}

install_method_initd_redhat()
{
    log "INFO: install_method_initd_redhat"

    local file=${SERVICE_FILE_PATH}

    echo "#!/bin/bash"                                                      >  ${file}
    if [ ! -e ${file} ] ; then
        set_err_code 21
        return
    fi

    echo ". /etc/init.d/functions"                                          >> ${file}
    echo "RETVAL=0"                                                         >> ${file}
    echo "PIDFILE=/run/oneavd.pid"                                          >> ${file}
    echo "prog=oneavd"                                                      >> ${file}
    echo "exec=${EDR_BIN_ONEEDRD}"                                          >> ${file}
    echo "args='${EDR_WORK_LINK} ${EDR_TITLE} &'"                           >> ${file}
    echo "start() {"                                                        >> ${file}
    echo "      [ -x \$exec ] || exit 5"                                    >> ${file}
    echo "      echo -n \$\"Starting threatbook oneav : \""                 >> ${file}
    echo "      daemon --pidfile=\"\$PIDFILE\" \$exec \$args"               >> ${file}
    echo "      RETVAL=\$?"                                                 >> ${file}
    echo "      echo"                                                       >> ${file}
    echo "      return \$RETVAL"                                            >> ${file}
    echo "}"                                                                >> ${file}
    echo "stop() {"                                                         >> ${file}
    echo "      echo -n \$\"Shutting down threatbook oneav : \""            >> ${file}
    echo "      killproc \$exec"                                            >> ${file}
    echo "      RETVAL=\$?"                                                 >> ${file}
    echo "      echo"                                                       >> ${file}
    echo "      return \$RETVAL"                                            >> ${file}
    echo "}"                                                                >> ${file}
    echo "rhstatus() {"                                                     >> ${file}
    echo "      status -l \$prog \$exec"                                    >> ${file}
    echo "}"                                                                >> ${file}
    echo "restart() {"                                                      >> ${file}
    echo "      stop"                                                       >> ${file}
    echo "      start"                                                      >> ${file}
    echo "}"                                                                >> ${file}
    echo "case \"\$1\" in"                                                  >> ${file}
    echo "  start)"                                                         >> ${file}
    echo "      start"                                                      >> ${file}
    echo "  ;;"                                                             >> ${file}
    echo "  stop)"                                                          >> ${file}
    echo "      stop"                                                       >> ${file}
    echo "  ;;"                                                             >> ${file}
    echo "  restart)"                                                       >> ${file}
    echo "      restart"                                                    >> ${file}
    echo "  ;;"                                                             >> ${file}
    echo "  status)"                                                        >> ${file}
    echo "      rhstatus"                                                   >> ${file}
    echo "  ;;"                                                             >> ${file}
    echo "  *)"                                                             >> ${file}
    echo "      echo \$\"Usage: \$0 {start|stop|restart|status}\""          >> ${file}
    echo "      exit 3"                                                     >> ${file}
    echo "esac"                                                             >> ${file}
    echo "exit \$?"                                                         >> ${file}
}

install_method_initd_debain()
{
    log "INFO: install_method_initd_debain"

    local file=${SERVICE_FILE_PATH}

    echo "#!/bin/bash"                                                      >  ${file}
    if [ ! -e ${file} ] ; then
        set_err_code 22
        return
    fi

    echo "DESC=\"threatbook oneavd\""                                       >> ${file}
    echo "DAEMON=${EDR_BIN_ONEEDRD}"                                        >> ${file}
    echo "PIDFILE=/run/oneavd.pid"                                          >> ${file}
    echo "SCRIPTNAME=/etc/init.d/oneavd"                                    >> ${file}
    echo "RETVAL=0"                                                         >> ${file}
    echo "OPTIONS='${EDR_WORK_LINK} ${EDR_TITLE}'"                          >> ${file}
    echo "[ -x \"\$DAEMON\" ] || exit 0"                                    >> ${file}
    echo ". /lib/lsb/init-functions"                                        >> ${file}
    echo "do_start() {"                                                     >> ${file}
    echo "  start-stop-daemon --start --background --make-pidfile --pidfile \$PIDFILE --exec \$DAEMON -- \$OPTIONS" >> ${file}
    echo "}"                                                                >> ${file}
    echo "do_stop() {"                                                      >> ${file}
    echo "  start-stop-daemon --stop --retry=TERM/3/KILL/3 --pidfile \$PIDFILE --exec \$DAEMON" >> ${file}
    echo "}"                                                                >> ${file}
    echo "case \"\$1\" in"                                                  >> ${file}
    echo "  start)"                                                         >> ${file}
    echo "      log_daemon_msg \"Starting \$DESC\""                         >> ${file}
    echo "      do_start"                                                   >> ${file}
    echo "  ;;"                                                             >> ${file}
    echo "  stop)"                                                          >> ${file}
    echo "      log_daemon_msg \"Stopping \$DESC\""                         >> ${file}
    echo "      do_stop"                                                    >> ${file}
    echo "      agent_pid=\`ps -ef|grep -v grep|grep -E \"threatbook.*oneavd\"| awk '{print \$2}'\` " >> ${file}
    echo "      if [ -n \"\$agent_pid\" ]; then"                            >> ${file}
    echo "          kill -n 9 \"\$agent_pid\" >/dev/null 2>&1"              >> ${file}
    echo "          rm -rf /var/run/oneavd.pid >/dev/null 2>&1"             >> ${file}
    echo "      fi"                                                         >> ${file}
    echo "  ;;"                                                             >> ${file}
    echo "  restart|force-reload)"                                          >> ${file}
    echo "      \$0 stop"                                                   >> ${file}
    echo "      \$0 start"                                                  >> ${file}
    echo "  ;;"                                                             >> ${file}
    echo "  status)"                                                        >> ${file}
    echo "      status_of_proc -p \$PIDFILE \$DAEMON && exit 0 || exit \$?" >> ${file}
    echo "  ;;"                                                             >> ${file}
    echo "  *)"                                                             >> ${file}
    echo "      echo \"Usage: \$SCRIPTNAME {start|stop|restart|force-reload|status}\" >&2" >> ${file}
    echo "      exit 3"                                                     >> ${file}
    echo "  ;;"                                                             >> ${file}
    echo "esac"                                                             >> ${file}
    echo "exit \$?"                                                         >> ${file}
}
install_method_initd_suse11()
{
    log "INFO: install_method_initd_suse11"

    local file=${SERVICE_FILE_PATH}

    echo "#!/bin/bash"                                                      >  ${file}
    if [ ! -e ${file} ] ; then
        set_err_code 23
        return
    fi

    echo "ONEAV_BIN=${EDR_BIN_ONEEDRD}"                                     >> ${file}
    echo ". /etc/rc.status"                                                 >> ${file}
    echo "rc_reset"                                                         >> ${file}
    echo "args='${EDR_WORK_LINK} ${EDR_TITLE} &'"                           >> ${file}
    echo "case \"\$1\" in"                                                  >> ${file}
    echo "  start)"                                                         >> ${file}
    echo "      echo -n \"Starting OneAV daemon\""                          >> ${file}
    echo "      export LC_ALL=\"\$RC_LC_ALL\""                              >> ${file}
    echo "      export LC_CTYPE=\"\$RC_LC_CTYPE\""                          >> ${file}
    echo "      export LANG="\$RC_LANG""                                    >> ${file}
    echo "      startproc \${ONEAV_BIN} ${EDR_WORK_LINK} ${EDR_TITLE}"      >> ${file}
    echo "      rc_status -v"                                               >> ${file}
    echo "      unset LC_ALL LC_CTYPE LANG"                                 >> ${file}
    echo "  ;;"                                                             >> ${file}
    echo "  stop)"                                                          >> ${file}
    echo "      echo -n \"Shutting down OneAV daemon \""                    >> ${file}
    echo "      killproc -KILL \${ONEAV_BIN}"                               >> ${file}
    echo "      rc_status -v"                                               >> ${file}
    echo "  ;;"                                                             >> ${file}
    echo "  restart)"                                                       >> ${file}
    echo "      \$0 stop "                                                  >> ${file}
    echo "      \$0 start "                                                 >> ${file}
    echo "      rc_status "                                                 >> ${file}
    echo "  ;;"                                                             >> ${file}
    echo "  status)"                                                        >> ${file}
    echo "      echo -n \"Checking for OneAV daemon\""                      >> ${file}
    echo "      checkproc \${ONEAV_BIN}"                                    >> ${file}
    echo "      rc_status -v "                                              >> ${file}
    echo "  ;;"                                                             >> ${file}
    echo "  *)"                                                             >> ${file}
    echo "      echo \$\"Usage: \$0 {start|stop|restart|status}\""          >> ${file}
    echo "      exit 3"                                                     >> ${file}
    echo "esac"                                                             >> ${file}
    echo "exit \$?"                                                         >> ${file}
}

RC_DIR=""
RC_DIRS=("/etc" "/etc/init.d" "/etc/rc.d")
RC_LEVELS=(2 3 4 5)
RC_LINK_NAME="S99${SERVICE_NAME}"

get_rc_dir()
{
    if [ -z "${RC_DIR}" ] || [ "${RC_DIR}" = "" ] ; then
        for dir in ${RC_DIRS[*]} ; do
            if [ -d "${dir}/rc0.d" ] ; then
                RC_DIR=${dir}
                break
            fi
        done
    fi
}
unlink_rc_link()
{
    get_rc_dir

    for level in ${RC_LEVELS[*]} ; do
        local link="${RC_DIR}/rc${level}.d/${RC_LINK_NAME}"
        if [ -f ${link} ] ; then
            unlink ${link}
        fi
    done
}
create_rc_link()
{
    get_rc_dir

    for level in ${RC_LEVELS[*]} ; do
        local link="${RC_DIR}/rc${level}.d/${RC_LINK_NAME}"

        ln -s $1 ${link}
    done
}

install_method_initd()
{
    select_initd_method

    SERVICE_FILE_PATH="${EDR_WORK_LINK}/conf/${SERVICE_FILE_INITD}"

    case ${INITD_METHOD_CODE} in
        ${INITD_METHOD_REDHAT}) install_method_initd_redhat ;;
        ${INITD_METHOD_DEBIAN}) install_method_initd_debain ;;
        ${INITD_METHOD_SUSE11}) install_method_initd_suse11 ;;
        *)                      install_method_initd_redhat ;;
    esac
    check_err_code_exit

    local service_file="${SERVICE_PATH_INITD}"

    cp -f "${SERVICE_FILE_PATH}" "${service_file}"
    if [ $? -eq 0 ] ; then
        log "\t[YES]: \tcreate ${SERVICE_FILE_INITD}"
        chmod +x ${service_file}
        unlink_rc_link
        create_rc_link "${service_file}"
    else
        log "\t [NO]: \tcreate ${SERVICE_FILE_INITD}"
        set_err_code 4
    fi
}

install_method_systemd()
{
    SERVICE_FILE_PATH="${EDR_WORK_LINK}/conf/${SERVICE_FILE_SYSTEMD}"

    local file=${SERVICE_FILE_PATH}
    local stage='multi-user.target'
    echo "[Unit]"                                                           >  ${file}
    echo "Description=ONEAV DAEMON"                                         >> ${file}
    echo "After=single-user.target"                                         >> ${file}
    echo "[Service]"                                                        >> ${file}
    echo "Type=simple"                                                      >> ${file}
    echo "ExecStart="${EDR_BIN_ONEEDRD}" "${EDR_WORK_LINK}" ${EDR_TITLE}"   >> ${file}
    echo "PIDFile=/run/threatbook/pid/oneederd.pid"                         >> ${file}
    echo "ExecStop=/bin/kill -TERM \$MAINPID"                               >> ${file}
    echo "Restart=on-failure"                                               >> ${file}
    echo "RestartSec=60"                                                    >> ${file}
    echo "LimitCORE=infinity"                                               >> ${file}
    echo "KillMode=process"                                                 >> ${file}
    echo "[Install]"                                                        >> ${file}
    echo "WantedBy=${stage}"                                                >> ${file}

    cp -f "${SERVICE_FILE_PATH}" "${SYS_SYSTEMD_DIR}/${SERVICE_FILE_SYSTEMD}"
    if [ $? -eq 0 ] ; then
        log "\t[YES]: \tcreate ${SERVICE_FILE_SYSTEMD}"
    else
        log "\t [NO]: \tcreate ${SERVICE_FILE_SYSTEMD}"

        set_err_code 5
        return
    fi

    systemctl enable ${SERVICE_FILE_SYSTEMD} >> /dev/null 2>&1
    if [ $? -eq 0 ] ; then
        log "\t[YES]: \tenable ${SERVICE_FILE_SYSTEMD}"
    else
        log "\t [NO]: \tenable ${SERVICE_FILE_SYSTEMD}"
    fi
}

uninstall_method_initd()
{
    local service_file="${SYS_INITD_DIR}/${SERVICE_NAME}"

    if [ -e ${service_file} ] ; then

        service ${SERVICE_NAME} stop > /dev/null 2>&1
        if [ $? -eq 0 ] ; then
            log "\t[YES]: \tstop service ${SERVICE_NAME}"
        else
            log "\t [NO]: \tstop service ${SERVICE_NAME}"
        fi

        unlink_rc_link

        rm ${service_file}
        if [ $? -eq 0 ] ; then
            log "\t[YES]: \trm ${service_file}"
        else
            log "\t [NO]: \trm ${service_file}"
        fi
    else
        log "INFO: no service need to uninstall"
    fi
}

uninstall_method_systemd()
{
    local service_file="${SYS_SYSTEMD_DIR}/${SERVICE_FILE_SYSTEMD}"

    if [ -e ${service_file} ] ; then
        systemctl stop ${SERVICE_NAME} > /dev/null 2>&1
        if [ $? -eq 0 ] ; then
            log "\t[YES]: \tstop    ${SERVICE_FILE_SYSTEMD}"
        else
            log "\t [NO]: \tstop    ${SERVICE_FILE_SYSTEMD}"
        fi

        systemctl disable ${SERVICE_NAME} > /dev/null 2>&1
        if [ $? -eq 0 ] ; then
            log "\t[YES]: \tdisable ${SERVICE_FILE_SYSTEMD}"
        else
            log "\t [NO]: \tdisable ${SERVICE_FILE_SYSTEMD}"
        fi

        rm ${service_file}
        if [ $? -eq 0 ] ; then
            log "\t[YES]: \trm ${service_file}"
        else
            log "\t [NO]: \trm ${service_file}"
        fi
    else
        log "INFO: no service need to uninstall"
    fi
}

install_service()
{
    who_is_first_process
    case $? in
        ${PROC_INITD})      install_method_initd    ;;
        ${PROC_SYSTEMD})    install_method_systemd  ;;
    esac
}

uninstall_service()
{
    who_is_first_process
    case $? in
        ${PROC_INITD})      uninstall_method_initd      ;;
        ${PROC_SYSTEMD})    uninstall_method_systemd    ;;
    esac
}

remove_user_link()
{
    local rm_counter=0

    unlink ${ONEEDR_LINK_STOP} >> /dev/null 2>&1
    if [ $? -eq 0 ] ; then
        rm_counter=$[ ${rm_counter} + 1 ]
    fi


    unlink ${ONEEDR_LINK_START} >> /dev/null 2>&1
    if [ $? -eq 0 ] ; then
        rm_counter=$[ ${rm_counter} + 1 ]
    fi

    if [ ${rm_counter} -gt 0 ] ; then
        log "\t[YES]: \tremove start/stop link"
    fi
}
create_user_link()
{
    remove_user_link

    local stop_script="${EDR_SCRIPT_DIR}/oneav_stop.sh"
    local start_script="${EDR_SCRIPT_DIR}/oneav_start.sh"

    chmod u+x ${stop_script}
    chmod u+x ${start_script}

    if [ -e ${stop_script} ] && [ -e ${start_script} ] ; then
        ln -s ${stop_script}  ${ONEEDR_LINK_STOP}
        ln -s ${start_script} ${ONEEDR_LINK_START}
        log "\t[YES]: \tcreate start/stop link"
    else
        log "\t [NO]: \tcreate start/stop link"
        set_err_code 1
    fi
}
oneedr_user_link() {
    case $1 in
        "install")      create_user_link    ;;
        "uninstall")    remove_user_link    ;;
    esac
}

copy_umid()
{
    if [ -f "${EDR_UMID}" ] ; then
        local key="umid"
        local umid=$(cat ${EDR_UMID})
        if [ -n "${umid}" ] ; then
            log "\t[YES]: \tumid value: ${umid}"
            local is_set=$(cat ${EDR_THOR_CONF} | grep "${key}" | wc -l)

            local is_ok=1
            if [ ${is_set} -eq 0 ] ; then
                # 配置文件中没有配置umid，则将umid写入。
                echo -e "${key}\t=\t\"${umid}\"" >> ${EDR_THOR_CONF}
                if [ $? -eq 0 ] ; then is_ok=0; fi
            else
                # 配置文件中配置了umid，则替换umid(先删除再添加，而不是直接替换)。
                sed -i "/${key}/d" ${EDR_THOR_CONF}
                if [ $? -eq 0 ] ; then
                    echo -e "${key}\t=\t\"${umid}\"" >> ${EDR_THOR_CONF}
                    if [ $? -eq 0 ] ; then is_ok=0; fi
                fi
            fi

            if [ ${is_ok} -eq 0 ] ; then
                log "\t[YES]: \tcopy umid: ${umid}"
            else
                log "\t [NO]: \tcopy umid: ${umid}"
                set_err_code 53
            fi
        else
            log "\t [NO]: \tumid value: ${umid}"
            set_err_code 52
            set_err_info "umid is empty"
        fi
    else
        log "\t [NO]: \tfound ${EDR_UMID}"
        set_err_code 51
        set_err_info "not found ${EDR_UMID}"
    fi
}

copy_proxy()
{
    if [ -f "${EDR_PROXY_CONF}" ] ; then
        local key="proxy_addr"
        local addr=$(cat ${EDR_PROXY_CONF})

        local is_set=$(cat ${EDR_THOR_CONF} | grep "${key}" | wc -l)

        local is_ok=1
        if [ ${is_set} -eq 0 ] ; then
            echo -e "${key}\t=\t\"${addr}\"" >> ${EDR_THOR_CONF}
            if [ $? -eq 0 ] ; then
                is_ok=0
            fi
        else
            sed -i "/${key}/d" ${EDR_THOR_CONF}
            if [ $? -eq 0 ] ; then
                echo -e "${key}\t=\t\"${addr}\"" >> ${EDR_THOR_CONF}
                if [ $? -eq 0 ] ; then
                    is_ok=0
                fi
            fi
        fi

        if [ ${is_ok} -eq 0 ] ; then
            log "\t[YES]: \tsave server addr: ${addr}"
        else
            log "\t [NO]: \tsave server addr: ${addr}"
            set_err_code 55
        fi
    else
        log "\t [NO]: \tfound proxy.conf"
        set_err_code 54
        set_err_info "not found proxy.conf"
    fi
}

check_script_start_user()
{
    if [ ${UID} -ne 0 ] ; then
        log "INFO: please run this script as root"
        set_err_code 18 "user not root"
        return 1
    fi
    return 0
}

is_alive()
{
    if [ "$1" -gt 0 ] && kill -0 "$1" >> /dev/null 2>&1 ; then
        return 0
    fi
    return 1
}

send_signal()
{
    if [ -z "$1" ] || [ -z "$2" ] ; then return 1; fi

    local pid="$1"
    local sig="$2"
    local name="$3"

    if [ "${pid}" -gt 0 ] ; then
        kill -"${sig}" "${pid}"
        if [ $? -eq 0 ] ; then
            log "\t[YES]: \tsend SIG: ${sig} to ${pid} ${name}"
        else
            log "\t [NO]: \tsend SIG: ${sig} to ${pid} ${name}"
        fi
    fi
    return 1
}

stop_running_service()
{
    log "INFO: try stop running service"

    local loop=$1
    local find_server=0

    local oneedrd_pid=0; oneedrd_pid=$(get_pid ${DAEMON})
    local onethor_pid=0; onethor_pid=$(get_pid ${ONETHOR})

    if [ "${oneedrd_pid}" -ne 0 ] || [ "${onethor_pid}" -ne 0 ] ; then
        for (( i=0; i<=loop; i++ )) ; do
            if is_alive "${oneedrd_pid}" ; then
                service_stop ${SERVICE_NAME}
                if [ $? -eq 0 ] ; then
                    log "\t[YES]: \tstop ${SERVICE_NAME} service"
                else
                    log "\t [NO]: \tstop ${SERVICE_NAME} service"
                fi
                continue
            else
                oneedrd_pid=0
            fi

            if is_alive "${onethor_pid}" ; then
                send_signal "${onethor_pid}" "SIGTERM" "${ONETHOR}"
            else
                onethor_pid=0
            fi

            if [ "${oneedrd_pid}" -ne 0 ] || [ "${onethor_pid}" -ne 0 ] ; then sleep 2; fi
        done
        find_server=1
    fi

    if [ ${oneedrd_pid} -gt 0 ] && is_alive "${oneedrd_pid}" ; then
        send_signal "${oneedrd_pid}" "SIGKILL" "${ONEEDRD}"; find_server=1
    fi
    if [ ${onethor_pid} -gt 0 ] && is_alive "${onethor_pid}" ; then
        send_signal "${onethor_pid}" "SIGKILL" "${ONETHOR}"; find_server=1
    fi

    if [ "${find_server}" -eq 0 ] ; then
        log "INFO: no service need to stop"
    fi
}

save_run_level()
{
    local key="run_level"
    local val=$1
    local is_ok=1
    if [ -f "${EDR_THOR_CONF}" ] ; then
        local is_set=""; is_set=$(grep -c "${key}" < "${EDR_THOR_CONF}")

        if [ "${is_set}" -eq 0 ] ; then
            if echo -e "${key}\t=\t${val}" >> ${EDR_THOR_CONF} ; then is_ok=0; fi
        elif sed -i "/${key}/d" ${EDR_THOR_CONF} ; then
            if echo -e "${key}\t=\t${val}" >> ${EDR_THOR_CONF} ; then is_ok=0; fi
        fi
    else
        log "\t [NO]: \tfound thor.conf"
        set_err_code 51 "not found thor.conf"
    fi
}

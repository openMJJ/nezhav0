#!/bin/bash

source /opt/threatbook/OneAV/OneAV/script/install/public_fun.sh

if [ -d $1 ]; then
    chmod 700 $1
fi

if [ ! -d $1/oneav_service_monitor.sh ]; then
    chmod 700 $1/oneav_service_monitor.sh
fi

if [ ! -d $1/oneav_start.sh ]; then
    chmod 700 $1/oneav_start.sh
fi

if [ ! -d $1/oneav_stop.sh ]; then
    chmod 700 $1/oneav_stop.sh
fi

if [ ! -d $1/public_fun.sh ]; then
    chmod 700 $1/public_fun.sh
fi

echo > /var/run/oneav.pid

install_crontab_task

service_stop    "oneavd"
service_start   "oneavd"


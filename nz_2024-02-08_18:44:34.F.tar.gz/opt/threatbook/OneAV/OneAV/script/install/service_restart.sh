#!/bin/bash
DIRNAME=$0
if [ "${DIRNAME:0:1}" = "/" ] ; then
    CURDIR=$(dirname "${DIRNAME}")
else
    CURDIR="$(pwd)"/"$(dirname "${DIRNAME}")"
fi
echo ">>>$CURDIR" >> /var/log/oneav_restart.log
source ${CURDIR}/public_fun.sh

chmod u+x ${CURDIR}/*

service_stop "oneavd"

copy_umid
copy_proxy
install_service
create_user_link
reload_crontab_task

service_start "oneavd"

#! /bin/bash

PATH=$PATH:/usr/local/sbin:/usr/local/bin:/sbin:/bin:/usr/sbin:/usr/bin:/root/bin
export PATH

ONEEDRD_PID=0
ONEEDRD_PPID=0
ONEEDRD_STAT=""

ONERTHOR_ROW=""
ONERTHOR_PID=0
ONERTHOR_PPID=0
ONERTHOR_STAT=""

PS_PID=1
PS_PPID=2
PS_STAT=3
PS_ARGS=4

ONEEDRD_ENABLE=1
ONERTHOR_ENABLE=1

ONEEDRD="oneavd"
ONERTHOR="oneav"

Update()
{
    local ps_out=$( ps -eo pid,ppid,stat,comm,args )

    local oneedrd_row=$( echo "${ps_out}" | grep -i 'threatbook.OneAV' | grep 'oneavd' )
    if [ -n "${oneedrd_row}" ] ; then
        local oneedrd_pid=$(  echo "$oneedrd_row" | awk "{print \$${PS_PID}}" )
        if [[ ${oneedrd_pid} -gt 0 ]] ; then
            ONEEDRD_PID=${oneedrd_pid}
        else
            ONEEDRD_PID=0
        fi

        local oneedrd_ppid=$( echo "$oneedrd_row" | awk "{print \$${PS_PPID}}" )
        if [[ ${oneedrd_ppid} -gt 0 ]] ; then
            ONEEDRD_PPID=${oneedrd_ppid}
        else
            ONEEDRD_PPID=0
        fi

        local oneedrd_stat=$( echo "$oneedrd_row" | awk "{print \$${PS_STAT}}" )
        if [[ -n ${oneedrd_stat} ]] ; then
            ONEEDRD_STAT=${oneedrd_stat}
        else
            ONEEDRD_STAT=""
        fi
    fi

    if [ -n "${oneedrd_row}" ] && [ ${ONEEDRD_PID} -gt 0 ] ; then
        local onerthor_row=$( echo "${ps_out}" | awk "\$${PS_PPID} == ${ONEEDRD_PID}{print \$0}" | grep 'oneav' )
        if [ -n "${onerthor_row}" ] ; then
            ONERTHOR_ROW=${onerthor_row}
        else
            ONERTHOR_ROW=""
        fi
    fi

    if [ -n "${ONERTHOR_ROW}" ] ; then
        local onerthor_pid=$(  echo "${ONERTHOR_ROW}" | awk "{print \$${PS_PID}}" )
        if [ -n "${onerthor_pid}" ] ; then
            ONERTHOR_PID=${onerthor_pid}
        else
            ONERTHOR_PID=0
        fi

        local onerthor_ppid=$( echo "${ONERTHOR_ROW}" | awk "{print \$${PS_PPID}}" )
        if [ -n "${onerthor_ppid}" ] ; then
            ONERTHOR_PPID=${onerthor_ppid}
        else
            ONERTHOR_PPID=0
        fi

        local onerthor_stat=$( echo "${ONERTHOR_ROW}" | awk "{print \$${PS_STAT}}" )
        if [ -n "${onerthor_stat}" ] ; then
            ONERTHOR_STAT=${onerthor_stat}
        else
            ONERTHOR_STAT=""
        fi
    fi
}

Check_User() {
    if [ ${UID} -ne 0 ] ; then
        Log "Error: Script user no root"
        exit 1
    fi
}

LOG_DIR="/var/log/oneav"
LOG_FILE="oneav_crontab.log"
LOG_PATH="${LOG_DIR}/${LOG_FILE}"

Log()
{
    echo -e "[ $(date "+%Y/%m/%d %T") ] [ $(basename $0) ]: $*" >> ${LOG_PATH}
#    echo -e "[ $(date  "+%Y/%m/%d %T") ] [ $(basename $0) ]: $*"
}

Check_LogFileSize()
{
    local max_size=2097152

    if [ -f ${LOG_FILE} ] ; then
        local size=$( ls -l ${LOG_FILE} | awk '{print $5}' )
        if [ ${size} -gt ${max_size} ] ; then
            rm ${LOG_FILE}
        fi
    fi
}

STAT_N=0
STAT_T=1
STAT_Z=2

Check_ProcStat()
{
    local proc=$1

    local stat
    local pid
    if [ "${proc}" = "${ONEEDRD}" ]; then
        stat="${ONEEDRD_STAT}"
        pid="${ONEEDRD_PID}"
    elif [ "${proc}" = "${ONERTHOR}" ]; then
        stat="${ONERTHOR_STAT}"
        pid="${ONERTHOR_PID}"
    fi

    if [[ "${stat}" =~ "T" ]]; then
        # Log "${proc} stat: ${stat} "
        kill -18 ${pid} >> /dev/null 2>&1
        if [ $? -ne 0 ] ; then
            Log "Fail: kill -18 ${pid}(${proc})"
        else
            echo "OK" >> /dev/null
            #Log "Success: kill -18 ${pid}(${proc})"
        fi
        return ${STAT_T}

    elif [[ "${stat}" =~ "Z" ]]; then
        Log "${proc} stat: ${stat} "
        return ${STAT_Z}
    fi

    return ${STAT_N}
}

TIMEOUT=1800
#TIMEOUT=6
TMP_DIR="/opt/threatbook/OneAV/oneav/tmp"
TIME_FILE_ONERTHOR="${TMP_DIR}/timestamp_oneav.txt"

Check_Time() {
    if [ -d "${TMP_DIR}" ] ; then
        echo "OK" >> /dev/null
    else
        mkdir ${TMP_DIR}
    fi

    local time=${TIMEOUT}
    local timestamp=0

    local proc=$1
    if [ "${proc} = ${ONERTHOR}" ]; then
        timestamp=${TIME_FILE_ONERTHOR}
    fi

    if [ -f "${timestamp}" ]; then
        local new_date=$(date "+%s")
        local old_date=$(cat ${timestamp})
        local value=$[ ${new_date} - ${old_date} ]

        if [ ${value} -ge ${time} ]; then
            echo ${new_date} > ${timestamp}
            Log "${proc} timeout"
            return 1
        else
            Log "Waiting ${ONEEDRD} wakeup ${proc}"
            return 0
        fi
    else
        local date=$(date "+%s")
        echo ${date} > ${timestamp}
        return 0
    fi
}

Update_Time() {
    local proc=$1
    local date=$(date "+%s")

    local time_file
    if [ "${proc}" = "${ONERTHOR}" ]; then
        time_file="${TIME_FILE_ONERTHOR}"
    fi

#    Log "Update ${proc} time: ${date}"
    echo "${date}" > ${time_file}

}

Check_ProcRelationship()
{
    if [ ${ONERTHOR_ENABLE} -ge 1 ] ; then
        if [ "${ONERTHOR_PPID}" != "${ONEEDRD_PID}" ] ; then
            Log "Incorrect relationship: ${ONERTHOR} and ${ONEEDRD}"
            Log "oneav_ppid: ${ONERTHOR_PPID}, oneavd_pid: ${ONEEDRD_PID}"
            kill -9 "${ONERTHOR_PID}"
            if [ $? -ne 0 ] ; then
                Log "Fail: kill -9 ${ONERTHOR_PID}(${ONERTHOR})"
            else
                Log "Success: kill -9 ${ONERTHOR_PID}(${ONERTHOR})"
            fi
            return 1
        fi
    fi

    return 0
}

Z_STAT_NUM=0
Z_STAT_MAX=1

Check_Process()
{
    if [ ${ONEEDRD_ENABLE} -ge 1 ] ; then
        if [ -z "${ONEEDRD_PID}" ] || [ ${ONEEDRD_PID} -eq 0 ] ; then
            Log "Not find ${ONEEDRD}"
            return ${ACTION_RESTART}
        fi
        Check_ProcStat "${ONEEDRD}"
        local result_oneedrd=$?
        if [ ${result_oneedrd} -eq ${STAT_T} ] ; then
            return ${ACTION_RECHECK}
        elif [ ${result_oneedrd} -eq ${STAT_Z} ] ; then
            return ${ACTION_RESTART}
        fi
    fi

    local is_wait_wakeup=0

    if [ ${ONERTHOR_ENABLE} -ge 1 ] ; then
        if [ -n "${ONERTHOR_PID}" ] && [ ${ONERTHOR_PID} -ne 0 ] ; then
            Update_Time "${ONERTHOR}"

            Check_ProcStat "${ONERTHOR}"
            local result_onerthor=$?
            if [ ${result_onerthor} -eq ${STAT_T} ] ; then
                return ${ACTION_RECHECK}
            elif [ ${result_onerthor} -eq ${STAT_Z} ] ; then
                if [ ${Z_STAT_NUM} -gt ${Z_STAT_MAX} ] ; then
                    Z_STAT_NUM=0
                    return ${ACTION_RESTART}
                else
                    Z_STAT_NUM=$[ ${Z_STAT_NUM} + 1 ]
                    return ${ACTION_RECHECK}
                fi
            fi
        else
            Log "Not find ${ONERTHOR}"
            Check_Time "${ONERTHOR}"
            if [ $? -ne 0 ] ; then
                return ${ACTION_RESTART}
            else
                is_wait_wakeup=1
            fi
        fi
    fi

    if [ ${is_wait_wakeup} -gt 0 ] ; then
        return ${ACTION_RECHECK}
    else
        Check_ProcRelationship
        if [ $? -ne 0 ] ; then
            return ${ACTION_RESTART}
        fi
    fi

    return ${ACTION_NORMAL}
}

Restart()
{
    local restart_method=$(ls -alF /proc/1/exe | grep systemd | wc -l)

    Log "Restart ${ONEEDRD}"

    if [ -n "${ONEEDRD_PID}" ] && [ ${ONEEDRD_PID} -gt 0 ] ; then
        kill -SIGTERM ${ONEEDRD_PID} >> /dev/null 2>&1
        sleep 1
    fi

    if [ ${restart_method} -eq 0 ] ; then
        service oneavd restart >> /dev/null 2>&1
    else
        systemctl restart oneavd >> /dev/null 2>&1
    fi
}

ACTION_NORMAL=0
ACTION_RESTART=1
ACTION_RECHECK=2
ACTION_WAIT=3

Main() {
    Check_User
    Check_LogFileSize

    for (( loop=1 ; loop<=5 ; ++loop )) ; do
        Update
        Check_Process
        local action=$?

        if [ ${action} -eq ${ACTION_NORMAL} ]; then
            Log "All is Normal"
            break
        elif [ ${action} -eq ${ACTION_RESTART} ]; then
            Log "Need restart"
            Restart
            sleep 15
        elif [ ${action} -eq ${ACTION_RECHECK} ]; then
            # Log "Need recheck"
            sleep 10
            continue
        fi
    done
}

cd /opt/threatbook/OneAV/oneav
Main

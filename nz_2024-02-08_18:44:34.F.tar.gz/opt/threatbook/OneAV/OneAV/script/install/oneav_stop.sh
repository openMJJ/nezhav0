#!/bin/bash

if [ ${UID} -ne 0 ] ; then
    echo "INFO: please run this script as root"
    exit
fi

source /opt/threatbook/OneAV/oneav/script/install/public_fun.sh

function is_stopped()
{
    local oneedrd_pid=0; oneedrd_pid=$(get_pid "${DAEMON}")
    local onethor_pid=0; onethor_pid=$(get_pid "${ONETHOR}")
    if [ "${oneedrd_pid}" -gt 0 ] || [ "${onethor_pid}" -gt 0 ] ; then
        log "\t [NO]: \toneav stop"
    else
        log "\t[YES]: \toneav stop"
    fi
}

log "INFO: oneav stop"

uninstall_crontab_task
if stop_running_service 5 ; then
    is_stopped
fi

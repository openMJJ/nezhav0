<?php
//数据库配置
$db_config = array(
    "type" => "mysql", //类型
	"host" => "mysql4.serv00.com", //地址
	"port" => 3306, //端口
	"name" => "m5707_twonav", //库名
	"user" => "m5707_twonav", //账号
	"password" => "Tss@19740522" //密码
);
?>
#!/bin/bash

# >>> Server Fill In >>>
TASK_ID="@TASK_ID@"
GROUP_ID="@GROUP_ID@"

ADDR_DOMAIN="@ADDR_DOMAIN@"
ADDR_DOWNLOAD_ID="@ADDR_DOWNLOAD_ID@"

SERVER_IP="@SERVER_IP@"
SERVER_PORT="@SERVER_PORT@"

INSTALL_MODE="@INSTALL_MODE@"

OS_TYPE="@OS_TYPE@"
AGENT_VERSION="@AGENT_VERSION@"
# <<< Server Fill In <<<

# the package download addr, like this: https://<domain>/agent/download?downloadId=<id>&umid=<id>&v=<timestamp>
UMID=""
PACKAGE_NAME="OneAV"
PACKAGE_ADDR=""
SERVER_URL_REGIST=""
SERVER_URL_RESULT=""

IS_ASK_UMID=0
IS_ASK_SERVER=1

# 安装包暂存目录
TMP_SAVE_DIR="/opt/threatbook/install_tmp"
PACKAGE_PATH="${TMP_SAVE_DIR}/${PACKAGE_NAME}.tar.gz"

# 日志变量
LOG_DIR="/var/log/oneav"
LOG_FILE="oneav_install.log"
LOG_PATH="${LOG_DIR}/${LOG_FILE}"
LOG_REDIRECT=0

# 错误码变量
ERR_CODE_MIN=100
ERR_CODE=${ERR_CODE_MIN}
ERR_INFO="OK"

# 项目变量
DAEMON="oneavd"
ONETHOR="oneav"

EDR_TITLE='threatbook.OneAV'
EDR_HOME_DIR="/opt/threatbook/OneAV"
EDR_WORK_LINK="${EDR_HOME_DIR}/oneav"

EDR_SCRIPT_DIR="${EDR_WORK_LINK}/script/install"
EDR_CONF_DIR="${EDR_WORK_LINK}/conf"
EDR_THOR_CONF="${EDR_WORK_LINK}/conf/thor.conf"
EDR_BIN_ONEEDRD="${EDR_WORK_LINK}/${DAEMON}"

# 系统相关目录
SYS_INITD_DIR="/etc/init.d"
SYS_SYSTEMD_DIR="/etc/systemd/system"

# 启动服务变量
SERVICE_NAME="oneavd"
SERVICE_FILE_INITD="${SERVICE_NAME}.sysv"
SERVICE_FILE_SYSTEMD="${SERVICE_NAME}.service"
SERVICE_FILE_PATH=""

SERVICE_PATH_INITD="${SYS_INITD_DIR}/${SERVICE_NAME}"
#SERVICE_PATH_SYSTEMD="${SYS_SYSTEMD_DIR}/${SERVICE_FILE_SYSTEMD}"

# 用户链接
ONEEDR_LINK_STOP="/usr/bin/oneav_stop"
ONEEDR_LINK_START="/usr/bin/oneav_start"
ONEEDR_LINK_ENABLE="/usr/bin/oneav_enable"
ONEEDR_LINK_DISABLE="/usr/bin/oneav_disable"

# 依赖工具数组
TOOLS_INSTALL=(cat grep wc sed ps chmod unlink ln pwd tar stat flock)
TOOLS_ONEEDRD=(mkdir mv rm echo ls ldd)
TOOLS_DOWNLOAD=(curl wget)
DOWNLOAD_TOOL_MARKER=""

# 计划任务变量
CRONTAB_FILE="/etc/crontab"

CRON_TASK_LOCK="${LOG_DIR}/cron.lock"
CRON_TASK_FILE_DIR="${EDR_SCRIPT_DIR}"
CRON_TASK_FILE_NAME='oneav_service_monitor.sh'

CRON_TASK_CMD="*/5 * * * * root flock -xn \"${CRON_TASK_LOCK}\" -c '${CRON_TASK_FILE_DIR}/${CRON_TASK_FILE_NAME}'"
CRON_TASK_KEY="${CRON_TASK_FILE_NAME}"

# 其他变量
RM_FILE_ARRAY=()
RUN_CHECK_TIME=5

STAT_ROLE=0
STAT_CODE=0

#bundle文件
BUNDLE_SWITCH=0
BUNDLE_TAR_NAME='@BUNDLE_TAR_NAME@'
BUNDLE_TAR_SIZE='@BUNDLE_TAR_SIZE@'
BUNDLE_START_TITLE='__ONEAV_ARCHIVE_BELLOW__'

# 环境变量
PATH=${PATH}:/sbin:/bin:/usr/sbin:/usr/bin

# The variables of script options and args
OPT_a=0; ARG_a=""
OPT_b=0
OPT_B=0; ARG_B=""
OPT_c=0
OPT_e=0
OPT_f=0
OPT_i=0
OPT_o=0; ARG_o=""
OPT_t=0; ARG_t=""
OPT_u=0


init_log()
{
    if [ ${LOG_REDIRECT} -eq 0 ] ; then
        if [ -d "${LOG_DIR}" ] ; then
            if [ ! -f "${LOG_PATH}" ] ; then
                touch "${LOG_PATH}"
            fi

            exec 3>&1
            exec 4>&2

            exec 1>>${LOG_PATH}
            exec 2>>${LOG_PATH}

            LOG_REDIRECT=1
        fi
    fi
}
uninit_log()
{
    if [ ${LOG_REDIRECT} -eq 1 ] ; then
        exec 1>&3
        exec 2>&4

        exec 3>&-
        exec 4>&-
        LOG_REDIRECT=0
    fi
}
log()
{
    echo -e "[ $(date "+%Y/%m/%d %T") ] [OneAV]  $*"
}

end_log()
{
    if [ ${LOG_REDIRECT} -eq 1 ] ; then
        uninit_log

        local name=""
        case ${STAT_ROLE} in
            1)  name="check"        ;;
            2)  name="install"      ;;
            3)  name="uninstall"    ;;
        esac
        if [ -n "${name}" ] && [ ${#name} -gt 1 ] ; then
            case ${STAT_CODE} in
                0)  log "${name} success"   ;;
                1)  log "${name} failed"    ;;
            esac
        fi

        log "script exit, more info see ${LOG_PATH}"
    fi
}

set_stat_role()
{
    if [ ${STAT_ROLE} -eq 0 ] ; then
        STAT_ROLE=$1
    fi
}

set_err_info()
{
    ERR_INFO="$*"
}
set_err_code()
{
    ERR_CODE=$(( ERR_CODE_MIN + $1 ))

    if [ -n "$2" ] ; then
        set_err_info "$2"
    fi

    return ${ERR_CODE}
}

check_err_code_show() {
    if [ ${ERR_CODE} -gt ${ERR_CODE_MIN} ] ; then
        log "CODE : err_code = ${ERR_CODE}"
        log "INFO : err_info = ${ERR_INFO}"
        return ${ERR_CODE}
    fi
}

check_err_code_zero() {
    check_err_code_show
    set_err_code 0
}

check_err_code_exit() {
    if [ ${ERR_CODE} -gt ${ERR_CODE_MIN} ] ; then
        if [ ${IS_ASK_SERVER} -eq 1 ] ; then
            send_http_result "${STEP_MARKER}"
        fi

        log "breakdown, err_code = ${ERR_CODE}"
        log "breakdown, err_info = ${ERR_INFO}"

        rm_array_exec
        STAT_CODE=1; end_log
        exit $(( ERR_CODE - ERR_CODE_MIN ))
    fi
}

HOST_IP=""
get_host_ip()
{
    if [ -z "${HOST_IP}" ] || [ "${HOST_IP}" = "" ] ; then
        local net_device_name="";net_device_name="$(ip route | grep -m 1 "default" | awk '{print $5}')"
        if [ -n "${net_device_name}" ] ; then
            local host_ip="";host_ip=$(ip addr | grep "${net_device_name}\$" | awk '{print $2}' | grep -o "^[^/]*")
            if [ -n "${host_ip}" ] ; then
                HOST_IP=${host_ip}
            fi
        fi
    fi
    echo "${HOST_IP}"
}

set_package_addr()
{
    if [ ${IS_ASK_SERVER} -eq 1 ] ; then
        local ip=""; ip=$(get_host_ip)
        if [ -n "${ip}" ] ; then
            local time="";time=$(date "+%s")
            PACKAGE_ADDR="https://${ADDR_DOMAIN}/agent/download?downloadId=${ADDR_DOWNLOAD_ID}&umid=${ip}&v=${time}"
            SERVER_URL_REGIST="https://${ADDR_DOMAIN}/agent/installer/register"
            SERVER_URL_RESULT="https://${ADDR_DOMAIN}/agent/installer/result"
            log "\t[YES]: \tset package addr: ${PACKAGE_ADDR}"
        else
            log "\t [NO]: \tset package addr"
            set_err_code 47 "set package addr failed"
        fi
    fi
}

check_variable()
{
    if [ -z "$1" ] ; then
        echo 0; return 0
    fi

    if [ $(( $(echo "$1" | grep -c "^@.*@$") )) -ne 0 ] ; then
        echo 0; return 0
    fi

    echo 1; return 1
}

get_json_value()
{
    local value=""
    value=$(echo "$1" | awk -F"[,:}]" '{for(i=1;i<=NF;i++){if($i~/'$2'\042/){print $(i+1)}}}' | tr -d '"' | sed -n ${num}p)
    echo "${value}"
}

exec_curl()
{
    if [ -n "$1" ] && [ -n "$2" ] ; then
        local time=10
        local response_msg=""
        local http_header="Content-Type:application/json;charset=UTF-8"

        case ${DOWNLOAD_TOOL_MARKER} in
        "curl") response_msg=$(curl -1 -k -s --connect-timeout ${time} -m ${time} -H "${http_header}" -d "$1" -L "$2")                         ;;
        "wget") response_msg=$(wget --secure-protocol=TLSv1 -q -T ${time} -w ${time} --header="${http_header}" --post-data="$1" --no-check-certificate "$2" -O -)   ;;
        esac
        if [ $? -eq 0 ] ; then
            if [ -n "${response_msg}" ] ; then
                echo "${response_msg}"; return
            else
                set_err_code 44 "empty response msg"
            fi
        else
            set_err_code 43 "failed to exec curl"
        fi
    fi
    echo ""
}

check_response()
{
    local response_msg="$1"
    log "RESP: ${1}"
    if [ -n "${response_msg}" ] && [ ${#response_msg} -gt 1 ] ; then
        local code=""; code=$(get_json_value "${response_msg}" "response_code")
        if [ -n "${code}" ] && [ "${code}" -eq 0 ] ; then
            if [ $(( $(check_variable "${TASK_ID}") )) -eq 0 ] ; then
                local task_id=""; task_id=$(get_json_value "${response_msg}" "taskId")
                if [ -n "${task_id}" ] && [ ${#task_id} -gt 1 ] ; then
                    TASK_ID="${task_id}"
                else
                    set_err_code 41 "parse taskID error"
                fi
            fi

            if [ ${IS_ASK_UMID} -eq 0 ] ; then
                local umid=""; umid=$(get_json_value "${response_msg}" "umId")
                if [ -n "${umid}" ] && [ ${#umid} -gt 1 ] ; then
                    UMID="${umid}"; IS_ASK_UMID=1
                    log "\t[YES]: \tserver return umId: ${umid}"
                else
                    log "\t [NO]: \tserver return umId: ${umid}"
                    set_err_code 56 "parse umId error"
                fi
            fi
        else
            log "${code}"
            set_err_code 40 "response code: ${code}, error"
        fi
    else
        set_err_code 39 "request install failed"
    fi
}

send_http_regist()
{
    if [ ${IS_ASK_SERVER} -eq 1 ] ; then
        log "INFO: request register"

        if [ $(( $(check_variable "${SERVER_URL_REGIST}") )) -eq 0 ] ; then
            set_err_code 44 "SERVER_URL_REGIST empty"
            return
        fi

        local host_ip=""; host_ip=$(get_host_ip)
        local host_name=""; host_name=$(echo "$(hostname)" | sed 's/ /-/g')
        local os_distro=""; os_distro=$(echo "$(get_linux_distro)" | sed 's/ /-/g')
        local os_kernel=""; os_kernel=$(echo "$(uname -r)" | sed 's/ /-/g')

        local regist_msg="{\"uuId\":\"\",\"umId\":\"${UMID}\",\"taskId\":\"${TASK_ID}\",\"groupId\":\"${GROUP_ID}\",\"osType\":\"${OS_TYPE}\",\"version\":\"${AGENT_VERSION}\",\"mode\":\"${INSTALL_MODE}\",\"hostIp\":\"${host_ip}\",\"hostName\":\"${host_name}\",\"osName\":\"${os_distro}\",\"kernelVersion\":\"${os_kernel}\"}"
        log "POST: ${regist_msg}"
        local response_msg=""; response_msg=$(exec_curl "${regist_msg}" "${SERVER_URL_REGIST}")
        check_response "${response_msg}"

        if [ ${ERR_CODE} -eq ${ERR_CODE_MIN} ] ; then
            log "\t[YES]: \trequest register"
        else
            log "\t [NO]: \trequest register"
            set_err_code 42 "failed to request register"
        fi
    fi

    if [ $(( $(check_variable "${TASK_ID}") )) -eq 1 ] ; then
        log "\t[YES]: \ttask id: ${TASK_ID}"
    else
        log "\t [NO]: \ttask id: ${TASK_ID}"
    fi
}

STEP_MARKER=""
STEP_CHECK="CHECK"
STEP_DOWNLOAD="DOWNLOAD"
STEP_INSTALL="INSTALLER"

send_http_result()
{
    if [ ${IS_ASK_SERVER} -eq 1 ] ; then
        if [ $(( $(check_variable "${SERVER_URL_RESULT}") )) -eq 0 ] ; then
            # set_err_info "SERVER_URL_RESULT empty"
            return
        fi

        local task_id="${TASK_ID}"
        local task_step="$1"
        local result_info=""; result_info="${ERR_INFO// /-}"
        local result_code=$(( ERR_CODE - ERR_CODE_MIN ))

        local result_msg="{\"taskId\":\"${task_id}\",\"taskStep\":\"${task_step}\",\"result\":\"${result_info}\",\"resultCode\":\"${result_code}\"}"
        log "POST: ${result_msg}"
        local response_msg=""; response_msg=$(exec_curl "${result_msg}" "${SERVER_URL_RESULT}")
        check_response "${response_msg}"
    fi
}

rm_array_add()
{
    RM_FILE_ARRAY[${#RM_FILE_ARRAY[*]}]=$1
}

rm_array_exec()
{
    local rm_cmd=""
    for path in "${RM_FILE_ARRAY[@]}" ; do
        if [ ${path} = "/" ] ; then continue; fi

        if [ -d ${path} ] ; then
            rm_cmd="rm -r ${path}"
        elif [ -f ${path} ] ; then
            rm_cmd="rm ${path}"
        fi

        if [ -e ${path} ] ; then
            ${rm_cmd} >> /dev/null 2>&1
            if [ $? -eq 0 ] ; then
                log "\t[YES]: \trm ${path}"
            else
                log "\t [NO]: \trm ${path}"
            fi
        fi
    done
    RM_FILE_ARRAY=()
}

get_pid()
{
    local pid=""; pid=$(ps xo pid,cmd | grep -i 'threatbook\.OneAV' | grep -m 1 "$1" | awk '{print $1}')
    if [ -z "${pid}" ] ; then
        echo 0
    else
        if [[ ${pid} == *[^0-9]* ]] ; then  # 只要含有非数字字符，都返回0，保证PID只能是数字
            echo 0
        else
            echo "${pid}"
        fi
    fi
}

get_linux_distro()
{

    local os_distro=""

    if [ "$(which lsb_release 2>/dev/null)" ] ; then
        local reg_lsb_info="Description:[[:space:]]*(.*)"
        local lsb_info=""; lsb_info=$(lsb_release -d)
        if [[ ${lsb_info} =~ ${reg_lsb_info} ]] ; then
            os_distro=${BASH_REMATCH[1]}
        fi
    else
        local reg_lsb_file="/etc/(.*)[-_]"
        local etc_files=""; etc_files=$(ls /etc/*[-_]{release,version} 2>/dev/null)
        for file in ${etc_files} ; do
            if [[ ${file} =~ ${reg_lsb_file} ]] ; then
                os_distro=${BASH_REMATCH[1]}
                os_distro=$(head -n1 < "${file}")
                break
            else
                break
            fi
        done
    fi

    # Red Hat and others
    if [ -e "/etc/redhat-release" ] ; then
        if [ -f "/etc/oracle-release" ] ; then
            os_distro=$(head -n1 < /etc/oracle-release)
        fi
    fi

    case ${os_distro} in
        suse)   os_distro="OpenSUSE"    ;;
        linux)  os_distro="LinuxMint"   ;;
    esac

    echo "${os_distro//\"/}"
}

create_dir()
{
    if [ -d "$1" ] ; then
        return 0
    elif mkdir -p "$1" ; then
        return 0
    fi
    return 1
}
remove_dir()
{
    if [ "$1" = "/" ] ; then
        return 1
    fi

    if [ -d $1 ] ; then
        rm -r $1
        if [ $? -eq 0 ] ; then
            return 0
        fi
    fi
    return 1
}

FIRST_PROC=0
PROC_INITD=1
PROC_SYSTEMD=2
# PROC_UNKNOWN=128
who_is_first_process()
{
    if [ ${FIRST_PROC} -eq 0 ] ; then
        local initd=""; initd=$(ls -alF /proc/1/exe | grep -c "init")
        local systemd=""; systemd=$(ls -alF /proc/1/exe | grep -c "systemd")

        if [ "${initd}" -eq 1 ] ; then
            FIRST_PROC=${PROC_INITD}
        elif [ "${systemd}" -eq 1 ] ; then
            FIRST_PROC=${PROC_SYSTEMD}
        fi
    fi
    return ${FIRST_PROC}
}

service_stop()
{
    who_is_first_process
    case $? in
        "${PROC_INITD}")      service "$1" stop     >> /dev/null 2>&1  ;;
        "${PROC_SYSTEMD}")    systemctl stop "$1"   >> /dev/null 2>&1  ;;
    esac
}
service_start()
{
    who_is_first_process
    case $? in
        "${PROC_INITD}")      service "$1" start    >> /dev/null 2>&1 ;;
        "${PROC_SYSTEMD}")    systemctl start "$1"  >> /dev/null 2>&1 ;;
    esac
}

remove_user_link()
{
    local rm_counter=0

    unlink ${ONEEDR_LINK_STOP} >> /dev/null 2>&1
    if [ $? -eq 0 ] ; then
        rm_counter=$(( rm_counter + 1 ))
    fi


    unlink ${ONEEDR_LINK_START} >> /dev/null 2>&1
    if [ $? -eq 0 ] ; then
        rm_counter=$(( rm_counter + 1 ))
    fi

    unlink ${ONEEDR_LINK_ENABLE} >> /dev/null 2>&1
    if [ $? -eq 0 ] ; then
        rm_counter=$(( rm_counter + 1 ))
    fi

    unlink ${ONEEDR_LINK_DISABLE} >> /dev/null 2>&1
    if [ $? -eq 0 ] ; then
        rm_counter=$(( rm_counter + 1 ))
    fi

    if [ "${rm_counter}" -gt 0 ] ; then
        log "\t[YES]: \tremove start/stop link"
    fi
}
create_user_link()
{
    remove_user_link

    local stop_script="${EDR_SCRIPT_DIR}/oneav_stop.sh"
    local start_script="${EDR_SCRIPT_DIR}/oneav_start.sh"
    local enable_script="${EDR_SCRIPT_DIR}/oneav_enable.sh"
    local disable_script="${EDR_SCRIPT_DIR}/oneav_disable.sh"

    chmod u+x ${stop_script}
    chmod u+x ${start_script}

    if [ -e ${stop_script} ] && [ -e ${start_script} ] ; then
        ln -s ${stop_script}  ${ONEEDR_LINK_STOP}
        ln -s ${start_script} ${ONEEDR_LINK_START}
        ln -s ${enable_script} ${ONEEDR_LINK_ENABLE}
        ln -s ${disable_script} ${ONEEDR_LINK_DISABLE}
        log "\t[YES]: \tcreate start/stop/enable/disable link"
    else
        log "\t [NO]: \tcreate start/stop/enable/disable link"
        set_err_code 1 "unable to create user link"
    fi
}
oneedr_user_link() {
    case $1 in
        "install")      create_user_link    ;;
        "uninstall")    remove_user_link    ;;
    esac
}

check_crontab_is_writable()
{
    # 检查crontab文件是否存在
    if [ -e ${CRONTAB_FILE} ] ; then
        if [ -w ${CRONTAB_FILE} ] ; then
            log "\t[YES]: \t${CRONTAB_FILE} writable"
        else
            log "\t [NO]: \t${CRONTAB_FILE} writable"
            set_err_info "unable to create the crontab task"
            # set_err_code 2
        fi
    else
        log "WARN: ${CRONTAB_FILE} does not exist"
        set_err_info "the crontab conf file could not be found"
        # set_err_code 3
    fi
}
reload_crontab_task()
{
    who_is_first_process
    case $? in
        "${PROC_INITD}")
            service crond restart >> /dev/null 2>&1
            if [ $? -ne 0 ] ; then
                service cron restart >> /dev/null 2>&1
            fi
        ;;
        "${PROC_SYSTEMD}")
            systemctl restart cron >> /dev/null 2>&1
            if [ $? -ne 0 ] ; then
                systemctl restart crond >> /dev/null 2>&1
            fi
        ;;
    esac

    if [ $? -eq 0 ] ; then
        log "\t[YES]: \treload crontab service"
    else
        log "\t [NO]: \treload crontab service"
    fi
}
install_crontab_task()
{
    chmod u+x "${CRON_TASK_FILE_DIR}/${CRON_TASK_FILE_NAME}"

    local if_repeat=""; if_repeat=$(grep -c "${CRON_TASK_KEY}" < /etc/crontab)
    if [ "${if_repeat}" -ne 0 ] ; then
        log "\t[YES]: \tinstall oneav crontab task"
    else
        echo "${CRON_TASK_CMD}" >> ${CRONTAB_FILE}
        if [ $? -eq 0 ] ; then
            log "\t[YES]: \tinstall oneav crontab task"
        else
            log "\t [NO]: \tinstall oneav crontab task"
        fi
        reload_crontab_task
    fi
}
uninstall_crontab_task()
{
    local if_repeat=""; if_repeat=$(grep -c "${CRON_TASK_KEY}" < /etc/crontab)

    if [ "${if_repeat}" -ne 0 ] ; then
        sed -i "/${CRON_TASK_KEY}/d" ${CRONTAB_FILE}
        if [ $? -eq 0 ] ; then
            log "\t[YES]: \tuninstall oneav cron task"
            reload_crontab_task
        else
            log "\t [NO]: \tuninstall oneav cron task"
        fi
    else
        log "INFO: no crontab task need to uninstall"
    fi
}

RC_DIR=""
RC_DIRS=("/etc" "/etc/init.d" "/etc/rc.d")
RC_LEVELS=(2 3 4 5)
RC_LINK_NAME="S99${SERVICE_NAME}"

get_rc_dir()
{
    if [ -z "${RC_DIR}" ] || [ "${RC_DIR}" = "" ] ; then
        for dir in "${RC_DIRS[@]}" ; do
            if [ -d "${dir}/rc0.d" ] ; then
                RC_DIR=${dir}
                break
            fi
        done
    fi
}
unlink_rc_link()
{
    get_rc_dir

    for level in "${RC_LEVELS[@]}" ; do
        local link="${RC_DIR}/rc${level}.d/${RC_LINK_NAME}"
        if [ -f "${link}" ] ; then
            unlink "${link}" >> /dev/null 2>&1
        fi
    done
}
create_rc_link()
{
    get_rc_dir

    for level in "${RC_LEVELS[@]}" ; do
        local link="${RC_DIR}/rc${level}.d/${RC_LINK_NAME}"

        ln -s "$1" "${link}"
    done
}

install_method_initd_redhat()
{
    log "INFO: install_method_initd_redhat"

    local file=${SERVICE_FILE_PATH}

    echo "#!/bin/bash"                                                      >  "${file}"
    if [ ! -e "${file}" ] ; then
        set_err_code 21 "unable to create ${file}"
        return
    fi

    echo ". /etc/init.d/functions"                                          >> "${file}"
    echo "RETVAL=0"                                                         >> "${file}"
    echo "PIDFILE=/run/oneavd.pid"                                          >> "${file}"
    echo "prog=oneavd"                                                      >> "${file}"
    echo "exec=${EDR_BIN_ONEEDRD}"                                          >> "${file}"
    echo "args='${EDR_WORK_LINK} ${EDR_TITLE} &'"                           >> "${file}"
    echo "start() {"                                                        >> "${file}"
    echo "      [ -x \$exec ] || exit 5"                                    >> "${file}"
    echo "      echo -n \$\"Starting threatbook oneav : \""                 >> "${file}"
    echo "      daemon --pidfile=\"\$PIDFILE\" \$exec \$args"               >> "${file}"
    echo '      echo ""'                                                    >> "${file}"
    echo "      RETVAL=\$?"                                                 >> "${file}"
    echo "      return \$RETVAL"                                            >> "${file}"
    echo "}"                                                                >> "${file}"
    echo "stop() {"                                                         >> "${file}"
    echo "      echo -n \$\"Shutting down threatbook oneav : \""            >> "${file}"
    echo "      killproc \$exec"                                            >> "${file}"
    echo "      RETVAL=\$?"                                                 >> "${file}"
    echo "      echo"                                                       >> "${file}"
    echo "      return \$RETVAL"                                            >> "${file}"
    echo "}"                                                                >> "${file}"
    echo "rhstatus() {"                                                     >> "${file}"
    echo "      status \$prog"                                              >> "${file}"
    echo "}"                                                                >> "${file}"
    echo "restart() {"                                                      >> "${file}"
    echo "      stop"                                                       >> "${file}"
    echo "      start"                                                      >> "${file}"
    echo "}"                                                                >> "${file}"
    echo "case \"\$1\" in"                                                  >> "${file}"
    echo "  start)"                                                         >> "${file}"
    echo "      start"                                                      >> "${file}"
    echo "  ;;"                                                             >> "${file}"
    echo "  stop)"                                                          >> "${file}"
    echo "      stop"                                                       >> "${file}"
    echo "  ;;"                                                             >> "${file}"
    echo "  restart)"                                                       >> "${file}"
    echo "      restart"                                                    >> "${file}"
    echo "  ;;"                                                             >> "${file}"
    echo "  status)"                                                        >> "${file}"
    echo "      rhstatus"                                                   >> "${file}"
    echo "  ;;"                                                             >> "${file}"
    echo "  *)"                                                             >> "${file}"
    echo "      echo \$\"Usage: \$0 {start|stop|restart|status}\""          >> "${file}"
    echo "      exit 3"                                                     >> "${file}"
    echo "esac"                                                             >> "${file}"
    echo "exit \$?"                                                         >> "${file}"
}

install_method_initd_debain()
{
    log "INFO: install_method_initd_debain"

    local file=${SERVICE_FILE_PATH}

    echo "#!/bin/bash"                                                      >  "${file}"
    if [ ! -e "${file}" ] ; then
        set_err_code 22 "unable to create ${file}"
        return
    fi

    echo "DESC=\"threatbook oneavd\""                                       >> "${file}"
    echo "DAEMON=${EDR_BIN_ONEEDRD}"                                        >> "${file}"
    echo "PIDFILE=/run/oneavd.pid"                                          >> "${file}"
    echo "SCRIPTNAME=/etc/init.d/oneavd"                                    >> "${file}"
    echo "RETVAL=0"                                                         >> "${file}"
    echo "OPTIONS='${EDR_WORK_LINK} ${EDR_TITLE}'"                          >> "${file}"
    echo "[ -x \"\$DAEMON\" ] || exit 0"                                    >> "${file}"
    echo ". /lib/lsb/init-functions"                                        >> "${file}"
    echo "do_start() {"                                                     >> "${file}"
    echo "  start-stop-daemon --start --background --make-pidfile --pidfile \$PIDFILE --exec \$DAEMON -- \$OPTIONS" >> "${file}"
    echo "}"                                                                >> "${file}"
    echo "do_stop() {"                                                      >> "${file}"
    echo "  start-stop-daemon --stop --retry=TERM/3/KILL/3 --pidfile \$PIDFILE --exec \$DAEMON"                     >> "${file}"
    echo "}"                                                                >> "${file}"
    echo "case \"\$1\" in"                                                  >> "${file}"
    echo "  start)"                                                         >> "${file}"
    echo "      log_daemon_msg \"Starting \$DESC\""                         >> "${file}"
    echo "      do_start"                                                   >> "${file}"
    echo "  ;;"                                                             >> "${file}"
    echo "  stop)"                                                          >> "${file}"
    echo "      log_daemon_msg \"Stopping \$DESC\""                         >> "${file}"
    echo "      do_stop"                                                    >> "${file}"
    echo "      agent_pid=\`ps -ef|grep -v grep|grep -E \"threatbook.*oneavd\"| awk '{print \$2}'\` "               >> "${file}"
    echo "      if [ -n \"\$agent_pid\" ]; then"                            >> "${file}"
    echo "          kill -n 9 \"\$agent_pid\" >/dev/null 2>&1"              >> "${file}"
    echo "          rm -rf /var/run/oneavd.pid >/dev/null 2>&1"             >> "${file}"
    echo "      fi"                                                         >> "${file}"
    echo "  ;;"                                                             >> "${file}"
    echo "  restart|force-reload)"                                          >> "${file}"
    echo "      \$0 stop"                                                   >> "${file}"
    echo "      \$0 start"                                                  >> "${file}"
    echo "  ;;"                                                             >> "${file}"
    echo "  status)"                                                        >> "${file}"
    echo "      status_of_proc -p \$PIDFILE \$DAEMON && exit 0 || exit \$?" >> "${file}"
    echo "  ;;"                                                             >> "${file}"
    echo "  *)"                                                             >> "${file}"
    echo "      echo \"Usage: \$SCRIPTNAME {start|stop|restart|force-reload|status}\" >&2"                          >> "${file}"
    echo "      exit 3"                                                     >> "${file}"
    echo "  ;;"                                                             >> "${file}"
    echo "esac"                                                             >> "${file}"
    echo "exit \$?"                                                         >> "${file}"
}
install_method_initd_suse11()
{
    log "INFO: install_method_initd_suse11"

    local file=${SERVICE_FILE_PATH}

    echo "#!/bin/bash"                                                      >  "${file}"
    if [ ! -e "${file}" ] ; then
        set_err_code 23 "unable to create ${file}"
        return
    fi

    echo "ONEAV_BIN=${EDR_BIN_ONEEDRD}"                                    >> "${file}"
    echo ". /etc/rc.status"                                                 >> "${file}"
    echo "rc_reset"                                                         >> "${file}"
    echo "args='${EDR_WORK_LINK} ${EDR_TITLE} &'"                           >> "${file}"
    echo "case \"\$1\" in"                                                  >> "${file}"
    echo "  start)"                                                         >> "${file}"
    echo "      echo -n \"Starting OneAV daemon\""                          >> "${file}"
    echo "      export LC_ALL=\"\$RC_LC_ALL\""                              >> "${file}"
    echo "      export LC_CTYPE=\"\$RC_LC_CTYPE\""                          >> "${file}"
    echo "      export LANG=\"\$RC_LANG\""                                  >> "${file}"
    echo "      startproc \${ONEAV_BIN} ${EDR_WORK_LINK} ${EDR_TITLE}"      >> "${file}"
    echo "      rc_status -v"                                               >> "${file}"
    echo "      unset LC_ALL LC_CTYPE LANG"                                 >> "${file}"
    echo "  ;;"                                                             >> "${file}"
    echo "  stop)"                                                          >> "${file}"
    echo "      echo -n \"Shutting down OneAV daemon \""                    >> "${file}"
    echo "      killproc -KILL \${ONEAV_BIN}"                               >> "${file}"
    echo "      rc_status -v"                                               >> "${file}"
    echo "  ;;"                                                             >> "${file}"
    echo "  restart)"                                                       >> "${file}"
    echo "      \$0 stop "                                                  >> "${file}"
    echo "      \$0 start "                                                 >> "${file}"
    echo "      rc_status "                                                 >> "${file}"
    echo "  ;;"                                                             >> "${file}"
    echo "  status)"                                                        >> "${file}"
    echo "      echo -n \"Checking for OneAV daemon\""                      >> "${file}"
    echo "      checkproc \${ONEAV_BIN}"                                    >> "${file}"
    echo "      rc_status -v "                                              >> "${file}"
    echo "  ;;"                                                             >> "${file}"
    echo "  *)"                                                             >> "${file}"
    echo "      echo \$\"Usage: \$0 {start|stop|restart|status}\""          >> "${file}"
    echo "      exit 3"                                                     >> "${file}"
    echo "esac"                                                             >> "${file}"
    echo "exit \$?"                                                         >> "${file}"
}


INITD_METHOD_CODE=0
INITD_METHOD_REDHAT=1
INITD_METHOD_DEBIAN=2
INITD_METHOD_SUSE11=3

judge_os_type()
{
    local info=""; info=$(cat "$1")

    if [ 0 -lt "$(echo "${info}" | grep -ciE "CentOS|Redhat")" ] ; then
        return ${INITD_METHOD_REDHAT}
    elif [ 0 -lt "$(echo "${info}" | grep -ciE "Ubuntu|Debian")" ] ; then
        return ${INITD_METHOD_DEBIAN}
    elif [ 0 -lt "$(echo "${info}" | grep -iE "SUSE" | grep -ciE "11")" ] ; then
        return ${INITD_METHOD_SUSE11}
    fi
    return 0
}

select_initd_method()
{
    local file_list=(/etc/issue /etc/os-release /etc/SuSE-release)

    for file_path in "${file_list[@]}" ; do

        if [ ${INITD_METHOD_CODE} -eq 0 ] && [ -f "${file_path}" ] ; then
            judge_os_type "${file_path}"
            local os_type=$?
            if [ ${os_type} -eq 0 ] ; then
                continue
            else
                INITD_METHOD_CODE=${os_type}
                break
            fi
        fi
    done
}

install_method_initd()
{
    select_initd_method

    SERVICE_FILE_PATH="${EDR_WORK_LINK}/conf/${SERVICE_FILE_INITD}"

    case ${INITD_METHOD_CODE} in
        "${INITD_METHOD_REDHAT}") install_method_initd_redhat ;;
        "${INITD_METHOD_DEBIAN}") install_method_initd_debain ;;
        "${INITD_METHOD_SUSE11}") install_method_initd_suse11 ;;
        *)                        install_method_initd_redhat ;;
    esac
    check_err_code_exit

    local service_file="${SERVICE_PATH_INITD}"

    cp -f "${SERVICE_FILE_PATH}" "${service_file}"
    if [ $? -eq 0 ] ; then
        log "\t[YES]: \tcreate ${SERVICE_FILE_INITD}"
        chmod +x ${service_file}
        unlink_rc_link
        create_rc_link "${service_file}"
    else
        log "\t [NO]: \tcreate ${SERVICE_FILE_INITD}"
        set_err_code 4 "unable to create ${SERVICE_FILE_INITD}"
    fi
}

uninstall_method_initd()
{
    # eg: service_file=/etc/init.d/oneavd
    local service_file="${SYS_INITD_DIR}/${SERVICE_NAME}"

    if [ -e ${service_file} ] ; then
        service ${SERVICE_NAME} stop > /dev/null 2>&1
        if [ $? -eq 0 ] ; then
            log "\t[YES]: \tstop service ${SERVICE_NAME}"
        else
            log "\t [NO]: \tstop service ${SERVICE_NAME}"
        fi

        unlink_rc_link

        rm ${service_file}
        if [ $? -eq 0 ] ; then
            log "\t[YES]: \trm ${service_file}"
        else
            log "\t [NO]: \trm ${service_file}"
        fi
    else
        log "INFO: no service need to uninstall"
    fi
}

install_method_systemd()
{
    SERVICE_FILE_PATH="${EDR_WORK_LINK}/conf/${SERVICE_FILE_SYSTEMD}"

    local file=${SERVICE_FILE_PATH}
    local stage='multi-user.target'
    echo "[Unit]"                                                           >  "${file}"
    echo "Description=ONEAV DAEMON"                                         >> "${file}"
    echo "After=single-user.target"                                         >> "${file}"
    echo "[Service]"                                                        >> "${file}"
    echo "Type=simple"                                                      >> "${file}"
    echo "ExecStart=${EDR_BIN_ONEEDRD} ${EDR_WORK_LINK} ${EDR_TITLE}"       >> "${file}"
    echo "PIDFile=/run/threatbook/pid/oneavd.pid"                         >> "${file}"
    echo "ExecStop=/bin/kill -TERM \$MAINPID"                               >> "${file}"
    echo "Restart=on-failure"                                               >> "${file}"
    echo "RestartSec=60"                                                    >> "${file}"
    echo "LimitCORE=infinity"                                               >> "${file}"
    echo "KillMode=process"                                                 >> "${file}"
    echo "[Install]"                                                        >> "${file}"
    echo "WantedBy=${stage}"                                                >> "${file}"

    cp -f "${SERVICE_FILE_PATH}" "${SYS_SYSTEMD_DIR}/${SERVICE_FILE_SYSTEMD}"
    if [ $? -eq 0 ] ; then
        log "\t[YES]: \tcreate ${SERVICE_FILE_SYSTEMD}"
    else
        log "\t [NO]: \tcreate ${SERVICE_FILE_SYSTEMD}"

        set_err_code 5 "unable to create ${SERVICE_FILE_SYSTEMD}"
        return
    fi

    systemctl enable ${SERVICE_FILE_SYSTEMD} >> /dev/null 2>&1
    if [ $? -eq 0 ] ; then
        log "\t[YES]: \tenable ${SERVICE_FILE_SYSTEMD}"
    else
        log "\t [NO]: \tenable ${SERVICE_FILE_SYSTEMD}"
    fi
}

uninstall_method_systemd()
{
    # eg: service_file=/etc/systemd/system/oneedrd.service
    local service_file="${SYS_SYSTEMD_DIR}/${SERVICE_FILE_SYSTEMD}"

    if [ -e ${service_file} ] ; then
        systemctl stop ${SERVICE_NAME} > /dev/null 2>&1
        if [ $? -eq 0 ] ; then
            log "\t[YES]: \tstop    ${SERVICE_FILE_SYSTEMD}"
        else
            log "\t [NO]: \tstop    ${SERVICE_FILE_SYSTEMD}"
        fi

        systemctl disable ${SERVICE_NAME} > /dev/null 2>&1
        if [ $? -eq 0 ] ; then
            log "\t[YES]: \tdisable ${SERVICE_FILE_SYSTEMD}"
        else
            log "\t [NO]: \tdisable ${SERVICE_FILE_SYSTEMD}"
        fi

        rm ${service_file}
        if [ $? -eq 0 ] ; then
            log "\t[YES]: \trm ${service_file}"
        else
            log "\t [NO]: \trm ${service_file}"
        fi
    else
        log "INFO: no service need to uninstall"
    fi
}

create_package_dir()
{
    if create_dir "${TMP_SAVE_DIR}" ; then
        log "\t[YES]: \tcreate dir ${TMP_SAVE_DIR}"
        rm_array_add "${TMP_SAVE_DIR}"
    else
        log "\t [NO]: \tcreate dir ${TMP_SAVE_DIR}"
        set_err_code 20 "failed to create dir: ${TMP_SAVE_DIR}"
    fi
}

remove_package_dir()
{
    remove_dir "${TMP_SAVE_DIR}"
    if [ $? -eq 0 ] ; then
        log "\t[YES]: \tremove dir ${TMP_SAVE_DIR}"
    else
        log "\t [NO]: \tremove dir ${TMP_SAVE_DIR}"
    fi
}

request_download_install_package()
{
    if [ $(( $(check_variable "${PACKAGE_ADDR}") )) -eq 0 ] ; then
        log "\t [NO]: \tpackage addr init"
        set_err_code 50 "package addr is empty"
    else
        log "\t[YES]: \tpackage addr init"
    fi
    check_err_code_exit

    local download_cmd=""
    case ${DOWNLOAD_TOOL_MARKER} in
        "curl") download_cmd="curl -1 -k -s -o ${PACKAGE_PATH} ${PACKAGE_ADDR}" ;;
        "wget") download_cmd="wget --secure-protocol=TLSv1 --no-check-certificate -q -O ${PACKAGE_PATH} ${PACKAGE_ADDR}" ;;
    esac

    if [ -z "${download_cmd}" ] || [ "${download_cmd}" = "" ] ; then
        log "WARN: no download tools"
        set_err_code 6 "download cmd error"
    else
        create_package_dir
        check_err_code_exit

        log "INFO: download cmd : ${download_cmd}"
        ${download_cmd} >> /dev/null 2>&1
        local cmd_code=$?
        log "INFO: download over, cmd return code=${cmd_code}"

        if [ ${cmd_code} -eq 0 ] && [ -f "${PACKAGE_PATH}" ] ; then
            log "\t[YES]: \tdownload install package"
        else
            log "\t [NO]: \tdownload install package"
            set_err_code 7 "failed to download install package"
        fi
    fi
}

get_umid()
{
    local thor_conf="${EDR_WORK_LINK}/conf/thor.conf"

    if [ $(( $(check_variable "${UMID}") )) -eq 0 ] ; then
        log "\t [NO]: \thave umid: ${UMID}"
        if [ -f "${thor_conf}" ] ; then
            local key="umid"
            local umid=""
            umid=$(grep -E "${key}\s*=\s*" < "${thor_conf}" | grep -oE "\"[0-9A-Za-z-]*\"" | sed "s/\"//g")
            if [ -n "${umid}" ] ; then
                UMID="${umid}"
                log "\t[YES]: \tfind umid: ${umid}"
            else
                log "\t [NO]: \tfind umid: ${umid}"
            fi
        else
            log "\t [NO]: \tfind umid: ${umid}"
        fi
    else
        UMID=""
        log "\t[YES]: \thave umid: ${UMID}"
    fi
}

save_umid()
{
    if [ $(( $(check_variable "${UMID}") )) -eq 1 ] && [ -f ${EDR_THOR_CONF} ] ; then
        local key="umid"
        local val="${UMID}"

        if write_conf "${key}" "${val}" ; then
            log "\t[YES]: \tsave umid: ${UMID}"
        else
            log "\t [NO]: \tsave umid: ${UMID}"
            set_err_code 53 "umid is empty"
        fi
    fi
}

decompress_prepare()
{
    if [ -e "${EDR_HOME_DIR}/${PACKAGE_NAME}" ] ; then
        log "WARN: ${EDR_HOME_DIR}/${PACKAGE_NAME} already exists"
        log "WARN: it will be delete, and it's not reversible"

        if [ -d "${EDR_CONF_DIR}" ] ; then
            if cp -r "${EDR_CONF_DIR}" "${TMP_SAVE_DIR}" ; then
                log "\t[YES]: \tcp dir: ${EDR_CONF_DIR}"
            else
                log "\t [NO]: \tcp dir: ${EDR_CONF_DIR}"
            fi
        fi

        # remove_dir "${EDR_HOME_DIR}/${PACKAGE_NAME}"
        if rm -rf /opt/threatbook/OneAV/* ; then
            log "\t[YES]: \trm dir: /opt/threatbook/OneAV/*"
        else
            log "\t [NO]: \trm dir: /opt/threatbook/OneAV/*"
        fi
    fi
}

decompress_install_package()
{
    log "INFO: start decompress ${PACKAGE_PATH}"

    if [ -e ${PACKAGE_PATH} ] ; then
        decompress_prepare

        if tar -zxf ${PACKAGE_PATH} -C ${EDR_HOME_DIR} >> /dev/null 2>&1 ; then
            log "\t[YES]: \tdecompress install package"
        else
            log "\t [NO]: \tdecompress install package"
            set_err_code 8 "failed to decompress install package"
        fi
    else
        log "WARN: not find install package"
        set_err_code 9 "not find install package"
    fi
}

backup_script()
{
    if [ -f $0 ] ; then
        cp $0 ${EDR_SCRIPT_DIR} >> /dev/null 2>&1
        if [ $? -eq 0 ] ; then
            log "\t[YES]: \tbackup the install script"
        else
            log "\t [NO]: \tbackup the install script"
            set_err_code 26 "unable to backup the install script"
        fi
    fi
}

write_conf()
{
    local key="$1"
    local val="$2"

    local is_ok=1
    if [ -f "${EDR_THOR_CONF}" ] ; then
        local is_set=""; is_set=$(grep -c "${key}" < "${EDR_THOR_CONF}")

        if [ "${is_set}" -eq 0 ] ; then
            if echo -e "${key}\t=\t\"${val}\"" >> ${EDR_THOR_CONF} ; then is_ok=0; fi
        elif sed -i "/${key}/d" ${EDR_THOR_CONF} ; then
            if echo -e "${key}\t=\t\"${val}\"" >> ${EDR_THOR_CONF} ; then is_ok=0; fi
        fi
    else
        log "\t [NO]: \tfound thor.conf"
        set_err_code 51 "not found thor.conf"
    fi
    return ${is_ok}
}

save_domain()
{
    local key="http_addr"
    local val="${ADDR_DOMAIN}"

    if write_conf "${key}" "${val}" ; then
        log "\t[YES]: \tsave http addr: ${val}"
    else
        log "\t [NO]: \tsave http addr: ${val}"
        set_err_code 57 "failed to save http addr"
    fi
}

save_server_addr()
{
    local key="proxy_addr"
    local val=""

    if [ $(( $(check_variable "${SERVER_IP}") )) -ne 0 ] ; then
        val="${SERVER_IP}"
    fi

    if [ $(( $(check_variable "${SERVER_PORT}") )) -ne 0 ] ; then
        val="${SERVER_IP}:${SERVER_PORT}"
    fi

    if write_conf "${key}" "${val}" ; then
        log "\t[YES]: \tsave server addr: ${val}"
    else
        log "\t [NO]: \tsave server addr: ${val}"
        set_err_code 24 "failed to save server addr"
    fi
}

is_alive()
{
    if [ "$1" -gt 0 ] && kill -0 "$1" >> /dev/null 2>&1 ; then
        return 0
    fi
    return 1
}

send_signal()
{
    if [ -z "$1" ] || [ -z "$2" ] ; then return 1; fi

    local pid="$1"
    local sig="$2"
    local name="$3"

    if [ "${pid}" -gt 0 ] ; then
        if kill -"${sig}" "${pid}" >> /dev/null 2>&1 ; then
            log "\t[YES]: \tsend SIG: ${sig} to ${pid} ${name}"
        else
            log "\t [NO]: \tsend SIG: ${sig} to ${pid} ${name}"
        fi
    fi
    return 1
}

stop_running_service()
{
    log "INFO: try stop running service"

    local loop=$1
    local find_server=0

    local oneedrd_pid=0; oneedrd_pid=$(get_pid ${DAEMON})
    local onethor_pid=0; onethor_pid=$(get_pid ${ONETHOR})

    if [ "${oneedrd_pid}" -ne 0 ] || [ "${onethor_pid}" -ne 0 ] ; then
        for (( i=0; i<=loop; i++ )) ; do
            if is_alive "${oneedrd_pid}" ; then
                service_stop ${SERVICE_NAME}
                if [ $? -eq 0 ] ; then
                    log "\t[YES]: \tstop ${SERVICE_NAME} service"
                else
                    log "\t [NO]: \tstop ${SERVICE_NAME} service"
                fi
                continue
            else
                oneedrd_pid=0
            fi

            if is_alive "${onethor_pid}" ; then
                send_signal "${onethor_pid}" "SIGTERM" "${ONETHOR}"
            else
                onethor_pid=0
            fi

            if [ "${oneedrd_pid}" -ne 0 ] || [ "${onethor_pid}" -ne 0 ] ; then sleep 2; fi
        done
        find_server=1
    fi

    if [ ${oneedrd_pid} -gt 0 ] && is_alive "${oneedrd_pid}" ; then
        send_signal "${oneedrd_pid}" "SIGKILL" "${ONEEDRD}"; find_server=1
    fi
    if [ ${onethor_pid} -gt 0 ] && is_alive "${onethor_pid}" ; then
        send_signal "${onethor_pid}" "SIGKILL" "${ONETHOR}"; find_server=1
    fi

    if [ "${find_server}" -eq 0 ] ; then
        log "INFO: no service need to stop"
    fi
}

install_prepare()
{
    log "INFO: install prepare"

    chmod u+x ${EDR_SCRIPT_DIR}/*   >> /dev/null 2>&1
    chmod -R 0700 ${EDR_HOME_DIR}   >> /dev/null 2>&1

    create_edr_work_link
    create_thor_conf

    if [ -d "${TMP_SAVE_DIR}/conf" ] ; then
        if cp -rf ${TMP_SAVE_DIR}/conf/* ${EDR_CONF_DIR}/ ; then
            log "\t[YES]: \tsave conf"
        else
            log "\t [NO]: \tsave conf"
        fi
    fi

    save_umid
    save_domain
    save_server_addr

    create_dir "${LOG_DIR}"
}

install_and_run()
{
    install_prepare
    check_err_code_exit

    log "INFO: in the installation"

    who_is_first_process
    case $? in
        "${PROC_INITD}")      install_method_initd    ;;
        "${PROC_SYSTEMD}")    install_method_systemd  ;;
    esac
    check_err_code_exit

    service_start ${SERVICE_NAME}
    if [ $? -eq 0 ] ; then
        log "\t[YES]: \tstart  ${SERVICE_NAME}"
    else
        log "\t [NO]: \tstart  ${SERVICE_NAME}"
        set_err_code 10 "failed to start ${SERVICE_NAME}"
    fi
    check_err_code_exit

    # backup_script
    # check_err_code_show

    install_crontab_task
    check_err_code_show

    create_user_link
    check_err_code_show
}

check_tool()
{
    local counter=""; counter=$(which "$1" 2>/dev/null | wc -l)
    if [ "${counter}" -ge 1 ] ; then
        return 0
    else
        return 1
    fi
    return 1
}

check_dependent_tools()
{
    if [ $# -eq 0 ] ; then
        log "WARN: check_dependent_tools() : please enter args"
        set_err_code 11 "args number error"
        return
    fi

    local no_find_tools=0
    for tool in "$@" ; do
        check_tool "${tool}"
        if [ $? -eq 0 ] ; then
            log "\t[YES]: \tTool ${tool}"
        else
            log "\t [NO]: \tTool ${tool}"
            no_find_tools=$(( no_find_tools + 1 ))
        fi
    done

    if [ ${no_find_tools} -ne 0 ] ; then
        set_err_code 12 "the dependency tool is missing"
    fi
}

check_download_tools()
{
    if [ ${OPT_f} -eq 1 ] ; then return 0; fi
    if [ -n "${DOWNLOAD_TOOL_MARKER}" ] ; then return 0; fi

    local find_tools=0
    for tool in "${TOOLS_DOWNLOAD[@]}" ; do
        check_tool "${tool}"
        if [ $? -eq 0 ] ; then
            log "\t[YES]: \tTool ${tool}"
            find_tools=$(( find_tools + 1 ))

            if [ -z "${DOWNLOAD_TOOL_MARKER}" ] || [ "${DOWNLOAD_TOOL_MARKER}" = "" ] ; then
                DOWNLOAD_TOOL_MARKER=${tool}
            fi
        else
            log "\t [NO]: \tTool ${tool}"
        fi
    done

    if [ ${find_tools} -eq 0 ] ; then
        set_err_code 13 "not have download tool"
    fi
}

create_thor_conf()
{
    if [ -f "${EDR_THOR_CONF}" ] ; then
        log "\t[YES]: \tfound thor.conf"
    else
        touch "${EDR_THOR_CONF}"
        if [ $? -eq 0 ] ; then
            log "\t[YES]: \ttouch thor.conf"
        else
            log "\t [NO]: \ttouch thor.conf"
            set_err_code 55 "failed to touch thor.conf"
        fi
    fi
}

create_edr_home_dir()
{
    if create_dir "${EDR_HOME_DIR}" ; then
        log "\t[YES]: \tcreate dir ${EDR_HOME_DIR}"
        chmod 0700 ${EDR_HOME_DIR} >> /dev/null 2>&1
    else
        log "\t [NO]: \tdir ${EDR_HOME_DIR}"
        set_err_code 14 "unable to create directory ${EDR_HOME_DIR}"
    fi
}
remove_edr_home_dir()
{
    remove_dir "${EDR_HOME_DIR}"
    if [ $? -eq 0 ] ; then
        log "\t[YES]: \tremove dir ${EDR_HOME_DIR}"
    fi
}
check_edr_home_dir()
{
    if [ -e ${EDR_HOME_DIR} ] ; then
        log "\t[YES]: \tDIR ${EDR_HOME_DIR}"
        return 0
    else
        log "\t [NO]: \tDIR ${EDR_HOME_DIR}"
        return 1
    fi
}

remove_edr_work_link()
{
    if [ "${EDR_WORK_LINK}" = '/' ] ; then return; fi

    unlink "${EDR_WORK_LINK}" >> /dev/null 2>&1
    if [ -e "${EDR_WORK_LINK}" ] ; then
        rm -r "${EDR_WORK_LINK}"
    fi
}
create_edr_work_link()
{
    remove_edr_work_link

    local obj_dir="${EDR_HOME_DIR}/${PACKAGE_NAME}"

    if [ -e ${obj_dir} ] ; then
        ln -s ${obj_dir} ${EDR_WORK_LINK}
        if [ $? -eq 0 ] && [ -d ${EDR_WORK_LINK} ] ; then
            log "\t[YES]: \tcreate work link: ${EDR_WORK_LINK} -> ${obj_dir}"
        else
            log "\t [NO]: \tcreate work link: ${EDR_WORK_LINK} -> ${obj_dir}"
            set_err_code 17 "failed to create work link"
        fi
    else
        log "\t [NO]: \tcreate work link: ${EDR_WORK_LINK} -> ${obj_dir}"
        set_err_code 27 "failed to create work link"
    fi
}

run_check()
{
    log "INFO: wait ${RUN_CHECK_TIME}s to check running."

    local times=${RUN_CHECK_TIME}
    while [ 0 -lt ${times} ] ; do
        log "INFO: countdown ${times}"

        local pid=""; pid=$(get_pid ${DAEMON})
        if [ "${pid}" -gt 0 ] ; then
            log "INFO: service already running"
            log "INFO: ${DAEMON} pid : ${pid}"
            log "INFO: install success"
            return 0
        fi

        sleep 1
        times=$(( times - 1 ))
    done
    log "INFO: install failed"
}

check_install_variable()
{
    if [ ${OPT_f} -eq 1 ] ; then return; fi

    local is_ok=0

    if [ $(( $(check_variable "${SERVER_IP}") )) -eq 0 ] ; then
        log "\t [NO]: \tSERVER_ADDR      = ${SERVER_IP}";
    else
        log "\t[YES]: \tSERVER_ADDR      = ${SERVER_IP}"; is_ok=1
    fi

    if [ $(( $(check_variable "${SERVER_PORT}") )) -eq 0 ] ; then
        log "\t [NO]: \tSERVER_PORT      = ${SERVER_PORT}";
    else
        log "\t[YES]: \tSERVER_PORT      = ${SERVER_PORT}"; is_ok=1
    fi

    if [ ${is_ok} -eq 0 ] ; then
        set_err_code 25 "the install base variable is not configured"
    fi
}

check_server_variable()
{
    if [ ${OPT_f} -eq 1 ] ; then return; fi

    local is_ok=0

    if [ ${IS_ASK_SERVER} -ne 0 ] ; then
        if [ $(( $(check_variable "${ADDR_DOMAIN}") )) -eq 0 ] ; then
            log "\t [NO]: \tADDR_DOMAIN      = ${ADDR_DOMAIN}"; is_ok=1
        else
            log "\t[YES]: \tADDR_DOMAIN      = ${ADDR_DOMAIN}"
        fi

        if [ $(( $(check_variable "${ADDR_DOWNLOAD_ID}") )) -eq 0 ] ; then
            log "\t [NO]: \tADDR_DOWNLOAD_ID = ${ADDR_DOWNLOAD_ID}"; is_ok=1
        else
            log "\t[YES]: \tADDR_DOWNLOAD_ID = ${ADDR_DOWNLOAD_ID}"
        fi
    fi

    if [ ${is_ok} -ne 0 ] ; then
        set_err_code 54 "the server base variable is not configured"
    fi
}

check()
{
    set_stat_role 1
    log "INFO: check dependency"

    check_install_variable

    if [ ${OPT_i} -ne 1 ] ; then
        check_server_variable
    fi
    check_download_tools

    check_dependent_tools "${TOOLS_INSTALL[@]}"

    check_dependent_tools "${TOOLS_ONEEDRD[@]}"

    check_crontab_is_writable

    if [ ${ERR_CODE} -eq ${ERR_CODE_MIN} ] ; then
        log "INFO: allow install"
    else
        log "WARN: not allow install"
    fi
}

install_with_tar()
{
    log "INFO: tar install mode"
    if [ ${OPT_t} -eq 1 ] && [ -f "${ARG_t}" ] ; then
        PACKAGE_PATH=${ARG_t}
        log "\t[YES]: \ttar path: ${ARG_t}"
    else
        log "\t [NO]: \ttar path: ${ARG_t}"
        set_err_code 34 "tar path no exist"
    fi
}

install_with_bundle()
{
    log "INFO: bundle install mode"

    if [ ${BUNDLE_SWITCH} -eq 1 ] ; then
        log "\t[YES]: \tallow bundle install"
        if [ $(( $(check_variable "${BUNDLE_TAR_SIZE}") )) -eq 0 ] ; then
            log "\t [NO]: \tbundle info right"
            set_err_code 38 "unable to get the bundle file size"
        elif [ -n "${BUNDLE_TAR_SIZE}" ] && [ ${BUNDLE_TAR_SIZE} -gt 1 ] ; then
            log "\t[YES]: \tbundle info right"
            create_package_dir
            check_err_code_exit

            tail -c ${BUNDLE_TAR_SIZE} "$0" > ${TMP_SAVE_DIR}/${BUNDLE_TAR_NAME}
            if [ $? -eq 0 ] ; then
                sync >> /dev/null 2>&1
                PACKAGE_PATH="${TMP_SAVE_DIR}/${BUNDLE_TAR_NAME}"
                log "\t[YES]: \tbundle release to ${PACKAGE_PATH}"
            else
                log "\t [NO]: \tbundle release to ${PACKAGE_PATH}"
                set_err_code 36 "release bundle failed"
            fi
        fi
    else
        log "\t [NO]: \tallow bundle install"
        set_err_code 35 "not bundle file"
    fi
}

install_check()
{
    get_umid

    if [ ${OPT_f} -eq 1 ] ; then
        check_dependent_tools "${TOOLS_INSTALL[@]}"

        check_dependent_tools "${TOOLS_ONEEDRD[@]}"

        check_crontab_is_writable

        if [ ${ERR_CODE} -eq ${ERR_CODE_MIN} ] ; then
            log "INFO: allow install"
        else
            log "WARN: not allow install"
        fi
    else
        check_server_variable
        check_err_code_exit

        set_package_addr
        check_err_code_exit

        send_http_regist
        check_err_code_exit

        check
        check_err_code_exit
    fi

    create_edr_home_dir
    check_err_code_exit
}

install_cleanup()
{
    rm_array_add "/var/log/onethor/repair.bundle"
    rm_array_exec
}

install()
{
    set_stat_role 2
    log "INFO: install service"

    check_download_tools
    check_err_code_exit

    STEP_MARKER=${STEP_CHECK}
        install_check
        check_err_code_exit
    send_http_result ${STEP_MARKER}


    STEP_MARKER=${STEP_DOWNLOAD}
        if [ ${OPT_t} -eq 1 ] ; then
            install_with_tar
        elif [ ${OPT_b} -eq 1 ] || [ ${BUNDLE_SWITCH} -eq 1 ] ; then
            install_with_bundle
        else
            request_download_install_package
        fi
        check_err_code_exit
    send_http_result ${STEP_MARKER}

    STEP_MARKER=${STEP_INSTALL}
        stop_running_service 5

        decompress_install_package
        check_err_code_exit

        install_and_run
        check_err_code_exit

        run_check
    send_http_result ${STEP_MARKER}

    install_cleanup
}

uninstall()
{
    set_stat_role 3
    log "INFO: uninstall process"

    uninstall_crontab_task

    stop_running_service 5

    who_is_first_process
    case $? in
        "${PROC_INITD}")      uninstall_method_initd      ;;
        "${PROC_SYSTEMD}")    uninstall_method_systemd    ;;
    esac

    remove_user_link
    remove_edr_home_dir

    log "INFO: uninstall success"
    if [ "${OPT_e}" -eq 1 ] ; then
        rm_array_add "/var/log/oneav"

        uninit_log
        rm_array_exec
    fi
}

make_bundle()
{
    log "INFO: make bunlde file"

    if [ ${OPT_B} -eq 1 ] && [ ${OPT_o} -eq 1 ] ; then
        log "\t[YES]: \tright options"
        if [ -f "${ARG_B}" ] && [ -n "${ARG_o}" ] && [ ${#ARG_o} -gt 0 ] ; then
            log "\t[YES]: \tright arguments "

            local tar_name=""; tar_name=$(echo "${ARG_B}" | grep -o "[^/]*$")
            local tar_size=""; tar_size=$(stat --format "%s" "${ARG_B}")
            if [ -n "${tar_size}" ] && [ "${tar_size}" -gt 0 ] ; then
                log "\t[YES]: \tget tar info"

                local r_code=0

                if [ -d "${ARG_o}" ] ; then
                    ARG_o="${ARG_o}/${tar_name}.bundle"
                fi

                cat "$0" > "${ARG_o}";                                      r_code=$(( r_code + $? ))
                sed -i "s/BUNDLE_SWITCH=0/BUNDLE_SWITCH=1/"     "${ARG_o}"; r_code=$(( r_code + $? ))
                sed -i "s/='@BUNDLE_TAR_NAME@'/='${tar_name}'/" "${ARG_o}"; r_code=$(( r_code + $? ))
                sed -i "s/='@BUNDLE_TAR_SIZE@'/=${tar_size}/"   "${ARG_o}"; r_code=$(( r_code + $? ))
                sync >> /dev/null 2>&1
                echo ""                                      >> "${ARG_o}"; r_code=$(( r_code + $? ))
                echo "exit"                                  >> "${ARG_o}"; r_code=$(( r_code + $? ))
                echo "${BUNDLE_START_TITLE}"                 >> "${ARG_o}"; r_code=$(( r_code + $? ))
                cat "${ARG_B}"                               >> "${ARG_o}"; r_code=$(( r_code + $? ))
                sync >> /dev/null 2>&1

                chmod +x "${ARG_o}"

                if [ ${r_code} -eq 0 ] ; then
                    log "\t[YES]: \tmake bundle success"
                else
                    log "\t [NO]: \tmake bundle success"
                    set_err_code 33 "failed to make bundle"
                fi
            else
                log "\t [NO]: \tget tar info"
                set_err_code 32 "failed to get tar info"
            fi
        else
            log "\t [NO]: \tright arguments"
            set_err_code 31 "args error"
        fi
    else
        log "\t [NO]: \tright options"
        set_err_code 30 "args error"
    fi
}

specify_server_add()
{
    log "INFO: set server address"
    if [ -n "$1" ] ; then
        log "\t[YES]: \tget server addr"

        local r_code=0; r_code=$(echo "${1}" | grep -cE '^(\S+:[0-9]+)$')
        if [ "${r_code}" -gt 0 ] ; then
            local ip="";   ip=$(echo "${1}"   | awk -F: '{print $1}')
            local port=""; port=$(echo "${1}" | awk -F: '{print $2}')

            if [ ${#ip} -gt 1 ] && [ ${#port} -gt 1 ] ; then
                SERVER_IP="${ip}"
                SERVER_PORT="${port}"
                log "INFO: server ADDR   : ${SERVER_IP}"
                log "INFO: server PORT   : ${SERVER_PORT}"
            else
                log "\t [NO]: \tused input server addr"
                set_err_code 37 "input server addr error"
            fi
        else
            SERVER_IP="${1}"
            SERVER_PORT=""
            log "INFO: server ADDR : ${SERVER_IP}"
        fi
    else
        log "\t [NO]: \tget server addr"
    fi
}

help_info()
{
    uninit_log

    echo "OneAV Service Install Script"
    echo ""
    echo "Usage: $0 [opt] <arg>"
    echo "  -a <addr> address of server specify, <addr>=IP:Port or <addr>=DOMAIN"
    echo '                                       eg: -a "192.168.100.100:22022" '
    echo '                                       eg: -a "www.test.com" '
    echo "  -b        bundle install mode, needs to be used with -i. only bundle file can use this"
    echo "  -B <tar>  use the <tar> to make bundle file, needs to be used with -o"
    echo "  -c        check environment"
    echo "  -e        entirely uninstall, needs to be used with -u"
    echo "  -f        force install, do not send the request of install to server"
    echo "  -h        help information"
    echo "  -i        install service, the default is remote install mode"
    echo "  -o <path> output path specify"
    echo "  -s        show log info to the screen, otherwise, log to ${LOG_PATH}"
    echo "  -t <tar>  tar install mode, needs to be used with -i"
    echo "  -u        uninstall service"
    echo ""
    echo "Note: options [-c -i -u -B], only one of them works at the same time"
    echo ""
}

debug_script()
{
    log "INFO : debug"
    # send_http_regist
    # check_err_code_show
    # send_http_result ${STEP_CHECK}
}

check_script_start_user()
{
    if [ ${UID} -ne 0 ] ; then
        log "INFO: please run this script as root"
        IS_ASK_SERVER=0
        set_err_code 18 "user not root"
    fi
}

run_with_input_args()
{
    if [ ${OPT_a} -eq 1 ] && [ -n "${ARG_a}" ] ; then
        specify_server_add "${ARG_a}"
        check_err_code_exit
    fi

    if   [ ${OPT_c} -eq 1 ] ; then
        check
    elif [ ${OPT_i} -eq 1 ] ; then
        install
    elif [ ${OPT_u} -eq 1 ] ; then
        uninstall
    elif [ ${OPT_B} -eq 1 ] ; then
        make_bundle
    fi
}

parse_input_args()
{
    if [ $# -lt 1 ] ; then
        if [ ${BUNDLE_SWITCH} -eq 1 ] ; then
            OPT_i=1; OPT_b=1;
        else
            help_info; return;
        fi
    fi

    case $1 in
        "install")  OPT_i=1                                     ;;
        "show")     uninit_log                                  ;;
    esac

    while getopts 'a:bB:cdefhio:st:u' opt ; do
        case ${opt} in
            a)      OPT_a=1; ARG_a="${OPTARG}"                  ;;
            b)      OPT_b=1                                     ;;
            B)      IS_ASK_SERVER=0; OPT_B=1; ARG_B="${OPTARG}" ;;
            c)      IS_ASK_SERVER=0; OPT_c=1                    ;;
            d)      debug_script                                ;;
            e)      OPT_e=1                                     ;;
            f)      IS_ASK_SERVER=0; OPT_f=1                    ;;
            i)      OPT_i=1                                     ;;
            o)      OPT_o=1; ARG_o="${OPTARG}"                  ;;
            s)      uninit_log                                  ;;
            t)      IS_ASK_SERVER=0; OPT_t=1; ARG_t="${OPTARG}" ;;
            u)      IS_ASK_SERVER=0; OPT_u=1                    ;;
            h|*)    IS_ASK_SERVER=0; help_info; return          ;;
        esac
    done

    run_with_input_args
}

run_script()
{
    check_script_start_user
    check_err_code_exit

    init_log

    parse_input_args "$@"
    check_err_code_show

    end_log

    uninit_log
}

run_script "$@"

#!/bin/bash

if [ ${UID} -ne 0 ] ; then
    echo "INFO: please run this script as root"
    exit
fi

source /opt/threatbook/OneAV/oneav/script/install/public_fun.sh

function is_started()
{
    local oneedrd_pid=0; oneedrd_pid=$(get_pid "${DAEMON}")
    if [ "${oneedrd_pid}" -gt 0 ] ; then
        log "\t[YES]: \toneav start"
    else
        log "\t [NO]: \toneav start"
    fi
}

log "INFO: oneav start"

service_start "oneavd"
install_crontab_task
is_started



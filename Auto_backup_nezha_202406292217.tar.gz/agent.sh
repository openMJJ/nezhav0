
#!/bin/sh
export TMPDIR=/home/openmjj/tmp

/home/openmjj/nezhapanel/agent -s 128.204.223.94:45555 -p HLTJOqCaYzFTu476gA

